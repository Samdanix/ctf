#!/bin/bash

# CTF Platform Deployment Script
# This script helps deploy the CTF platform using Docker

set -e

echo "🚀 Starting CTF Platform Deployment..."

# Check if .env file exists
if [ ! -f .env ]; then
    echo "⚠️  .env file not found. Creating from .env.example..."
    cp .env.example .env
    echo "⚠️  Please edit .env file and set your SECRET_KEY before continuing!"
    echo "   You can generate a secret key with: python -c 'from django.core.management.utils import get_random_secret_key; print(get_random_secret_key())'"
    exit 1
fi

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo "❌ Docker is not installed. Please install Docker first."
    exit 1
fi

# Check if Docker Compose is installed (v2 or v1)
if docker compose version &> /dev/null; then
    DOCKER_COMPOSE="docker compose"
elif command -v docker-compose &> /dev/null; then
    DOCKER_COMPOSE="docker-compose"
else
    echo "❌ Docker Compose is not installed. Please install Docker Compose first."
    exit 1
fi

echo "Using: $DOCKER_COMPOSE"

# Stop existing containers
echo "🛑 Stopping existing containers..."
$DOCKER_COMPOSE down || true

# Build and start containers
echo "🔨 Building Docker images..."
$DOCKER_COMPOSE build

echo "🚀 Starting containers..."
$DOCKER_COMPOSE up -d

# Wait for the web service to be ready
echo "⏳ Waiting for web service to be ready..."
sleep 5

# Run migrations
echo "📦 Running database migrations..."
$DOCKER_COMPOSE exec -T web python manage.py migrate

# Create superuser (optional - comment out if not needed)
echo "👤 To create a superuser, run:"
echo "   $DOCKER_COMPOSE exec web python manage.py createsuperuser"

echo ""
echo "✅ Deployment complete!"
echo ""
echo "🌐 Your CTF platform should be accessible at:"
echo "   - https://uapcyberforge.xyz"
echo "   - https://www.uapcyberforge.xyz"
echo ""
echo "📊 Useful commands:"
echo "   - View logs: $DOCKER_COMPOSE logs -f"
echo "   - Stop services: $DOCKER_COMPOSE down"
echo "   - Restart services: $DOCKER_COMPOSE restart"
echo "   - Access Django shell: $DOCKER_COMPOSE exec web python manage.py shell"
echo ""
