from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
from django.db.models import Sum, Count
import hashlib

class Category(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    icon = models.CharField(max_length=50, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name_plural = "Categories"
        ordering = ['name']

    def __str__(self):
        return self.name

class Contest(models.Model):
    STATUS_CHOICES = [
        ('upcoming', 'Upcoming'),
        ('active', 'Active'),
        ('ended', 'Ended'),
    ]
    
    name = models.CharField(max_length=255)
    description = models.TextField()
    start_time = models.DateTimeField()
    end_time = models.DateTimeField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='upcoming')
    is_monthly = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    # ── Leaderboard freeze ────────────────────────────────────────────────
    leaderboard_frozen = models.BooleanField(
        default=False,
        help_text="When frozen, participants see standings as of the freeze time."
    )
    freeze_time = models.DateTimeField(
        null=True, blank=True,
        help_text="Solves after this time are hidden from participants (admins still see all)."
    )

    class Meta:
        ordering = ['-start_time']

    def __str__(self):
        return self.name

    def is_active(self):
        now = timezone.now()
        return self.start_time <= now <= self.end_time

    def update_status(self):
        now = timezone.now()
        if now < self.start_time:
            self.status = 'upcoming'
        elif self.start_time <= now <= self.end_time:
            self.status = 'active'
        else:
            self.status = 'ended'
        self.save()

    def get_leaderboard(self, for_admin=False):
        """
        Return ranked participants for this contest.

        for_admin=True  → counts ALL solves (real-time standings).
        for_admin=False → if frozen, only counts solves up to freeze_time;
                          otherwise counts all solves.
        """
        use_freeze = (
            not for_admin
            and self.leaderboard_frozen
            and self.freeze_time is not None
        )

        solve_qs = Solve.objects.filter(problem__contest=self)
        if use_freeze:
            solve_qs = solve_qs.filter(solved_at__lte=self.freeze_time)

        # All users who have at least one solve in the contest (shown even if 0 pts after freeze)
        all_participant_ids = (
            Solve.objects.filter(problem__contest=self)
            .values_list('user_id', flat=True)
            .distinct()
        )

        from django.contrib.auth.models import User as _User
        participants = _User.objects.filter(
            id__in=all_participant_ids,
            is_superuser=False,
        )

        rows = []
        for user in participants:
            user_solves = solve_qs.filter(user=user)
            pts = user_solves.aggregate(s=Sum('points_awarded'))['s'] or 0
            cnt = user_solves.count()
            last = user_solves.order_by('solved_at').last()
            last_time = last.solved_at if last else None

            # Pending solves hidden behind the freeze wall
            pending = 0
            if use_freeze:
                pending = (
                    Solve.objects.filter(
                        user=user,
                        problem__contest=self,
                        solved_at__gt=self.freeze_time,
                    ).count()
                )

            rows.append({
                'user': user,
                'total_points': pts,
                'solve_count': cnt,
                'last_solve_time': last_time,
                'pending_solves': pending,
            })

        # Sort: points desc, then earliest last-solve asc (tiebreak)
        rows.sort(key=lambda r: (
            -r['total_points'],
            r['last_solve_time'] or timezone.now(),
        ))

        for i, row in enumerate(rows, 1):
            row['rank'] = i

        return rows

class Problem(models.Model):
    DIFFICULTY_CHOICES = [
        ('easy', 'Easy'),
        ('medium', 'Medium'),
        ('hard', 'Hard'),
        ('expert', 'Expert'),
    ]
    
    SCORING_TYPE_CHOICES = [
        ('static', 'Static'),
        ('dynamic', 'Dynamic'),
    ]

    title = models.CharField(max_length=255)
    description = models.TextField()
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='problems')
    flag = models.CharField(max_length=255, help_text="The actual flag (will be hashed)")
    points = models.IntegerField()
    difficulty = models.CharField(max_length=20, choices=DIFFICULTY_CHOICES, default='medium')
    
    # Contest relation (null if it's a practice problem)
    contest = models.ForeignKey(Contest, on_delete=models.CASCADE, null=True, blank=True, related_name='problems')
    
    # Author
    author = models.CharField(max_length=100, default='Admin', help_text="Challenge author name")
    
    # File attachments
    file_url = models.URLField(blank=True, help_text="URL to challenge files")
    challenge_file = models.FileField(upload_to='challenges/', blank=True, null=True, help_text="Upload challenge file")
    hint = models.TextField(blank=True)
    
    # Scoring system
    scoring_type = models.CharField(
        max_length=20, 
        choices=SCORING_TYPE_CHOICES, 
        default='static',
        help_text="Static = fixed points, Dynamic = points decrease with solves"
    )
    initial_points = models.IntegerField(help_text="Starting points (for dynamic) or fixed points (for static)")
    minimum_points = models.IntegerField(help_text="Minimum points after decay (dynamic only)")
    decay_value = models.IntegerField(
        default=10,
        help_text="Points deducted per solve (dynamic only)"
    )
    
    # Attempt limits
    max_attempts = models.IntegerField(default=0, help_text="Maximum attempts allowed (0 = unlimited)")
    
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return self.title

    def get_flag_hash(self):
        return hashlib.sha256(self.flag.encode()).hexdigest()

    def check_flag(self, submitted_flag):
        return self.flag == submitted_flag.strip()

    def get_solve_count(self):
        return self.solves.count()
    
    def get_user_attempts(self, user):
        """Get number of attempts by a specific user"""
        return self.submissions.filter(user=user).count()
    
    def can_attempt(self, user):
        """Check if user can still attempt this challenge"""
        if self.max_attempts == 0:  # Unlimited attempts
            return True
        
        attempts = self.get_user_attempts(user)
        return attempts < self.max_attempts
    
    def remaining_attempts(self, user):
        """Get remaining attempts for a user"""
        if self.max_attempts == 0:
            return "Unlimited"
        
        attempts = self.get_user_attempts(user)
        remaining = self.max_attempts - attempts
        return max(0, remaining)

    def get_current_points(self):
        """Calculate current points based on scoring type"""
        if self.scoring_type == 'static':
            # Static scoring: always return initial_points
            return self.initial_points
        
        # Dynamic scoring: points decrease with each solve
        solve_count = self.get_solve_count()
        if solve_count == 0:
            return self.initial_points
        
        # Deduct decay_value points for each solve
        current_points = self.initial_points - (self.decay_value * solve_count)
        
        # Ensure points don't go below minimum_points
        return max(self.minimum_points, current_points)

class Solve(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='solves')
    problem = models.ForeignKey(Problem, on_delete=models.CASCADE, related_name='solves')
    solved_at = models.DateTimeField(auto_now_add=True)
    points_awarded = models.IntegerField()

    class Meta:
        unique_together = ['user', 'problem']
        ordering = ['-solved_at']

    def __str__(self):
        return f"{self.user.username} solved {self.problem.title}"

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    bio = models.TextField(blank=True)
    country = models.CharField(max_length=100, blank=True)
    website = models.URLField(blank=True)
    avatar_url = models.URLField(blank=True)
    phone = models.CharField(max_length=11, blank=True, help_text="11 digit phone number")
    total_points = models.IntegerField(default=0)
    rank = models.IntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username}'s profile"

    def update_total_points(self):
        total = self.user.solves.aggregate(Sum('points_awarded'))['points_awarded__sum'] or 0
        self.total_points = total
        self.save()

    def get_solve_count(self):
        return self.user.solves.count()

class Submission(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='submissions')
    problem = models.ForeignKey(Problem, on_delete=models.CASCADE, related_name='submissions')
    submitted_flag = models.CharField(max_length=255)
    is_correct = models.BooleanField(default=False)
    submitted_at = models.DateTimeField(auto_now_add=True)
    ip_address = models.GenericIPAddressField(null=True, blank=True)

    class Meta:
        ordering = ['-submitted_at']

    def __str__(self):
        return f"{self.user.username} - {self.problem.title} - {'✓' if self.is_correct else '✗'}"

class BlockedIP(models.Model):
    ip_address = models.GenericIPAddressField(unique=True)
    reason = models.CharField(max_length=255, blank=True, default='Blocked by admin')
    blocked_by = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, related_name='blocked_ips'
    )
    blocked_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-blocked_at']
        verbose_name = 'Blocked IP'
        verbose_name_plural = 'Blocked IPs'

    def __str__(self):
        return f"{self.ip_address} (blocked by {self.blocked_by})"


class Announcement(models.Model):
    title = models.CharField(max_length=255)
    content = models.TextField()
    created_by = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return self.title
