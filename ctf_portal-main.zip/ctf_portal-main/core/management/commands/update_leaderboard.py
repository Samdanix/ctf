from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from django.db.models import Sum
from core.models import UserProfile

class Command(BaseCommand):
    help = 'Update user rankings on the leaderboard'

    def handle(self, *args, **options):
        users = User.objects.annotate(
            total_points=Sum('solves__points_awarded')
        ).filter(total_points__gt=0).order_by('-total_points')
        
        for rank, user in enumerate(users, start=1):
            profile, created = UserProfile.objects.get_or_create(user=user)
            profile.rank = rank
            profile.total_points = user.total_points
            profile.save()
        
        self.stdout.write(
            self.style.SUCCESS(
                f'Successfully updated rankings for {users.count()} users'
            )
        )
