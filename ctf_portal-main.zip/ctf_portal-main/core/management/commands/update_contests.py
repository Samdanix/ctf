from django.core.management.base import BaseCommand
from core.models import Contest

class Command(BaseCommand):
    help = 'Update contest statuses based on current time'

    def handle(self, *args, **options):
        contests = Contest.objects.all()
        updated = 0
        
        for contest in contests:
            old_status = contest.status
            contest.update_status()
            if old_status != contest.status:
                updated += 1
                self.stdout.write(
                    self.style.SUCCESS(
                        f'Updated {contest.name}: {old_status} -> {contest.status}'
                    )
                )
        
        self.stdout.write(
            self.style.SUCCESS(f'Successfully updated {updated} contests')
        )
