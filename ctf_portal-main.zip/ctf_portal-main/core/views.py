from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib import messages
from django.db.models import Sum, Count, Q
from django.utils import timezone
from django.http import JsonResponse
from django.utils.http import url_has_allowed_host_and_scheme
from .models import Problem, Category, Solve, Contest, UserProfile, Submission, Announcement
from django.contrib.auth.models import User
from core.middleware import get_client_ip, _is_rate_limited

def home(request):
    """Homepage with announcements and stats"""
    announcements = Announcement.objects.filter(is_active=True)[:5]
    total_users = User.objects.count()
    total_problems = Problem.objects.filter(is_active=True).count()
    total_solves = Solve.objects.count()
    
    # Active contests
    active_contests = Contest.objects.filter(status='active')
    upcoming_contests = Contest.objects.filter(status='upcoming')[:3]
    
    context = {
        'announcements': announcements,
        'total_users': total_users,
        'total_problems': total_problems,
        'total_solves': total_solves,
        'active_contests': active_contests,
        'upcoming_contests': upcoming_contests,
        'user_authenticated': request.user.is_authenticated,
    }
    return render(request, 'home.html', context)

def challenges(request):
    """Practice challenges page"""
    categories = Category.objects.all()
    selected_category = request.GET.get('category')
    difficulty = request.GET.get('difficulty')
    
    problems = Problem.objects.filter(is_active=True, contest__isnull=True)
    
    if selected_category:
        problems = problems.filter(category_id=selected_category)
    if difficulty:
        problems = problems.filter(difficulty=difficulty)
    
    # Add solve status for authenticated users
    if request.user.is_authenticated:
        solved_ids = Solve.objects.filter(user=request.user).values_list('problem_id', flat=True)
    else:
        solved_ids = []
    
    context = {
        'problems': problems,
        'categories': categories,
        'selected_category': selected_category,
        'difficulty': difficulty,
        'solved_ids': solved_ids,
    }
    return render(request, 'challenges.html', context)

def challenge_detail(request, problem_id):
    """Individual challenge page - viewable by all, but submission requires login"""
    problem = get_object_or_404(Problem, id=problem_id, is_active=True)
    
    # Initialize variables for authenticated users
    already_solved = False
    remaining_attempts = "Login required"
    
    if request.user.is_authenticated:
        # Check if user already solved it
        already_solved = Solve.objects.filter(user=request.user, problem=problem).exists()
        
        # Get remaining attempts for this user
        remaining_attempts = problem.remaining_attempts(request.user)
    
    # Get recent solves
    recent_solves = Solve.objects.filter(problem=problem).select_related('user')[:10]
    
    context = {
        'problem': problem,
        'already_solved': already_solved,
        'recent_solves': recent_solves,
        'current_points': problem.get_current_points(),
        'solve_count': problem.get_solve_count(),
        'remaining_attempts': remaining_attempts,
        'user_authenticated': request.user.is_authenticated,
    }
    return render(request, 'challenge_detail.html', context)

@login_required
def submit_flag(request, problem_id):
    """Handle flag submission — always records the submitter's IP."""
    if request.method != "POST":
        return redirect('challenge_detail', problem_id=problem_id)

    problem = get_object_or_404(Problem, id=problem_id, is_active=True)
    submitted_flag = request.POST.get("flag", "").strip()

    # ── Capture real client IP ──────────────────────────────────────────────
    ip_address = get_client_ip(request)

    # ── Per-user rate limiting: max 10 submissions per minute ───────────────
    rate_key = f'flag_submit:{request.user.id}'
    if _is_rate_limited(rate_key, max_requests=10, window=60):
        messages.error(request, "Too many submissions. Please wait a moment before trying again.")
        return redirect('challenge_detail', problem_id=problem_id)

    # Check if already solved
    already_solved = Solve.objects.filter(user=request.user, problem=problem).exists()

    if already_solved:
        messages.warning(request, "You've already solved this challenge!")
        return redirect('challenge_detail', problem_id=problem_id)

    # Check max attempts
    if not problem.can_attempt(request.user):
        messages.error(request, f"Maximum attempts ({problem.max_attempts}) reached for this challenge!")
        return redirect('challenge_detail', problem_id=problem_id)

    # Check flag
    is_correct = problem.check_flag(submitted_flag)

    # Record submission (IP always stored)
    Submission.objects.create(
        user=request.user,
        problem=problem,
        submitted_flag=submitted_flag,
        is_correct=is_correct,
        ip_address=ip_address
    )

    if is_correct:
        points = problem.get_current_points()
        Solve.objects.create(
            user=request.user,
            problem=problem,
            points_awarded=points
        )
        profile, _ = UserProfile.objects.get_or_create(user=request.user)
        profile.update_total_points()
        messages.success(request, f"Correct! You earned {points} points! 🎉")
    else:
        remaining = problem.remaining_attempts(request.user)
        if problem.max_attempts > 0:
            messages.error(request, f"Incorrect flag. {remaining} attempt(s) remaining.")
        else:
            messages.error(request, "Incorrect flag. Try again!")

    return redirect('challenge_detail', problem_id=problem_id)

def leaderboard(request):
    """Global leaderboard - excludes superusers"""
    contest_id = request.GET.get('contest')
    
    if contest_id:
        # Contest-specific leaderboard
        contest = get_object_or_404(Contest, id=contest_id)
        users = User.objects.filter(
            solves__problem__contest=contest,
            is_superuser=False  # Exclude superusers
        ).annotate(
            total_points=Sum('solves__points_awarded'),
            solve_count=Count('solves', distinct=True)
        ).order_by('-total_points')
        
        context = {
            'users': users,
            'contest': contest,
            'is_contest': True,
        }
    else:
        # Global leaderboard
        users = User.objects.filter(
            is_superuser=False  # Exclude superusers
        ).annotate(
            total_points=Sum('solves__points_awarded'),
            solve_count=Count('solves', distinct=True)
        ).filter(total_points__gt=0).order_by('-total_points')[:100]
        
        context = {
            'users': users,
            'is_contest': False,
        }
    
    return render(request, 'leaderboard.html', context)

def contests(request):
    """List all contests"""
    active = Contest.objects.filter(status='active')
    upcoming = Contest.objects.filter(status='upcoming')
    ended = Contest.objects.filter(status='ended')[:10]
    
    context = {
        'active_contests': active,
        'upcoming_contests': upcoming,
        'ended_contests': ended,
        'user_authenticated': request.user.is_authenticated,
    }
    return render(request, 'contests.html', context)

@login_required
def contest_detail(request, contest_id):
    """Contest detail page - requires login to view"""
    contest = get_object_or_404(Contest, id=contest_id)
    contest.update_status()
    
    problems = Problem.objects.filter(contest=contest, is_active=True)
    
    # Check solved problems
    solved_ids = Solve.objects.filter(
        user=request.user,
        problem__contest=contest
    ).values_list('problem_id', flat=True)
    
    # Use the model's leaderboard method — respects freeze for non-admins
    is_admin = request.user.is_staff or request.user.is_superuser
    leaderboard = contest.get_leaderboard(for_admin=is_admin)
    
    context = {
        'contest': contest,
        'problems': problems,
        'solved_ids': solved_ids,
        'leaderboard': leaderboard,
        'is_admin': is_admin,
    }
    return render(request, 'contest_detail.html', context)

@login_required
def profile(request, username=None):
    """User profile page"""
    if username:
        user = get_object_or_404(User, username=username)
    else:
        user = request.user
    
    profile, created = UserProfile.objects.get_or_create(user=user)
    solves = Solve.objects.filter(user=user).select_related('problem', 'problem__category').order_by('-solved_at')
    
    # Calculate stats
    total_points = solves.aggregate(Sum('points_awarded'))['points_awarded__sum'] or 0
    solve_count = solves.count()
    
    # Category breakdown
    category_stats = solves.values('problem__category__name').annotate(
        count=Count('id'),
        points=Sum('points_awarded')
    ).order_by('-points')
    
    context = {
        'profile_user': user,
        'profile': profile,
        'solves': solves,
        'total_points': total_points,
        'solve_count': solve_count,
        'category_stats': category_stats,
    }
    return render(request, 'profile.html', context)

def register(request):
    """User registration with email and phone validation"""
    if request.user.is_authenticated:
        return redirect('home')
    
    if request.method == 'POST':
        from .forms import CustomUserCreationForm
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, f"Welcome {user.username}! Your account has been created.")
            return redirect('home')
    else:
        from .forms import CustomUserCreationForm
        form = CustomUserCreationForm()
    
    return render(request, 'register.html', {'form': form})

def user_login(request):
    """User login"""
    if request.user.is_authenticated:
        return redirect('home')
    
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.success(request, f"Welcome back, {username}!")
                # Safe redirect: only allow same-origin next URLs
                next_url = request.POST.get('next') or request.GET.get('next', '')
                if next_url and url_has_allowed_host_and_scheme(
                    url=next_url,
                    allowed_hosts={request.get_host()},
                    require_https=request.is_secure(),
                ):
                    return redirect(next_url)
                return redirect('home')
    else:
        form = AuthenticationForm()
    
    return render(request, 'login.html', {'form': form})

def user_logout(request):
    """User logout — only accepts POST to prevent CSRF logout."""
    if request.method == 'POST':
        logout(request)
        messages.info(request, "You've been logged out successfully.")
    return redirect('home')

@login_required
def download_challenge_file(request, problem_id):
    """Download challenge file - requires authentication"""
    problem = get_object_or_404(Problem, id=problem_id, is_active=True)
    
    if not problem.challenge_file:
        messages.error(request, "No file available for this challenge.")
        return redirect('challenge_detail', problem_id=problem_id)
    
    # Return the file for download
    from django.http import FileResponse
    import os
    
    file_path = problem.challenge_file.path
    if os.path.exists(file_path):
        response = FileResponse(
            open(file_path, 'rb'),  # FileResponse closes the file handle automatically
            as_attachment=True,
            filename=os.path.basename(file_path)
        )
        return response
    else:
        messages.error(request, "File not found.")
        return redirect('challenge_detail', problem_id=problem_id)

# API endpoints for dynamic updates
@login_required
def api_leaderboard(request):
    """JSON API for leaderboard - excludes superusers"""
    users = User.objects.filter(
        is_superuser=False  # Exclude superusers
    ).annotate(
        total_points=Sum('solves__points_awarded'),
        solve_count=Count('solves')
    ).filter(total_points__gt=0).order_by('-total_points')[:50]
    
    data = [{
        'rank': idx + 1,
        'username': user.username,
        'points': user.total_points or 0,
        'solves': user.solve_count or 0,
    } for idx, user in enumerate(users)]
    
    return JsonResponse({'leaderboard': data})
