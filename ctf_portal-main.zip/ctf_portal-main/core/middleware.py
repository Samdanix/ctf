"""
Security middleware for UAP Cyber Forge CTF platform.

Provides:
  - BlockedIPMiddleware   — blocks requests from IPs in the BlockedIP table
  - SecurityHeadersMiddleware — injects CSP, HSTS, and other security headers
  - RateLimitMiddleware   — simple in-memory rate limiting for sensitive endpoints
"""

import time
import threading
from collections import defaultdict

from django.http import HttpResponseForbidden, HttpResponse
from django.utils.deprecation import MiddlewareMixin


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def get_client_ip(request):
    """
    Extract the real client IP from request headers.

    Only trusts X-Forwarded-For when the site is behind a known reverse proxy
    (i.e. not in DEBUG mode).  In development the header is accepted as-is so
    local testing still works.
    """
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        # Take the *first* (leftmost) address — that is the original client.
        # Strip any port number that some proxies append.
        ip = x_forwarded_for.split(',')[0].strip().split(':')[0]
        return ip
    return request.META.get('REMOTE_ADDR', '')


# ─────────────────────────────────────────────────────────────────────────────
# BlockedIPMiddleware
# ─────────────────────────────────────────────────────────────────────────────

class BlockedIPMiddleware(MiddlewareMixin):
    """
    Blocks requests from IPs stored in the BlockedIP table.
    The Django admin path remains accessible so staff can manage the list.
    """

    EXEMPT_PATHS = ['/secure-mangement-core-9fA7xP3-secure-panel-AlphaZero-2026/django/']

    def process_request(self, request):
        for path in self.EXEMPT_PATHS:
            if request.path.startswith(path):
                return None

        ip = get_client_ip(request)
        if not ip:
            return None

        try:
            from .models import BlockedIP
            if BlockedIP.objects.filter(ip_address=ip).exists():
                return HttpResponseForbidden(
                    "<h1 style='font-family:monospace;color:#ff0055;background:#0a0e1a;"
                    "padding:2rem;'>403 — Your IP address has been blocked.<br>"
                    "<small style='color:#5b8fb9'>Contact the administrator if you "
                    "believe this is a mistake.</small></h1>"
                )
        except Exception:
            # DB not ready yet — let the request through
            pass

        return None


# ─────────────────────────────────────────────────────────────────────────────
# SecurityHeadersMiddleware
# ─────────────────────────────────────────────────────────────────────────────

class SecurityHeadersMiddleware(MiddlewareMixin):
    """
    Adds security-related HTTP response headers to every response.

    Headers set:
      - Content-Security-Policy   — restricts resource origins (XSS mitigation)
      - X-Content-Type-Options    — prevents MIME-type sniffing
      - X-Frame-Options           — clickjacking protection (also set by Django)
      - X-XSS-Protection          — legacy browser XSS filter
      - Referrer-Policy           — limits referrer information leakage
      - Permissions-Policy        — disables unused browser features
      - Cache-Control             — prevents caching of authenticated pages
    """

    # Content-Security-Policy
    # Allows:
    #   - scripts/styles from self + Google Fonts CDN
    #   - fonts from Google Fonts CDN
    #   - images from self + data URIs
    # Blocks everything else by default.
    CSP = (
        "default-src 'self'; "
        "script-src 'self' 'unsafe-inline'; "          # unsafe-inline needed for inline <script> blocks in templates
        "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
        "font-src 'self' https://fonts.gstatic.com; "
        "img-src 'self' data:; "
        "connect-src 'self'; "
        "frame-ancestors 'none'; "                     # equivalent to X-Frame-Options: DENY
        "base-uri 'self'; "
        "form-action 'self';"                          # forms may only POST to same origin
    )

    def process_response(self, request, response):
        # CSP
        response['Content-Security-Policy'] = self.CSP

        # Prevent MIME sniffing
        response['X-Content-Type-Options'] = 'nosniff'

        # Clickjacking (belt-and-suspenders alongside Django's XFrameOptionsMiddleware)
        response['X-Frame-Options'] = 'DENY'

        # Legacy XSS filter for older browsers
        response['X-XSS-Protection'] = '1; mode=block'

        # Referrer policy — don't leak URL to third parties
        response['Referrer-Policy'] = 'strict-origin-when-cross-origin'

        # Disable unused browser features
        response['Permissions-Policy'] = (
            'geolocation=(), microphone=(), camera=(), '
            'payment=(), usb=(), magnetometer=(), gyroscope=()'
        )

        # Prevent caching of authenticated / sensitive pages
        if request.user.is_authenticated if hasattr(request, 'user') else False:
            response['Cache-Control'] = 'no-store, no-cache, must-revalidate, private'
            response['Pragma'] = 'no-cache'

        return response


# ─────────────────────────────────────────────────────────────────────────────
# Simple in-memory rate limiter
# ─────────────────────────────────────────────────────────────────────────────

_rate_limit_lock = threading.Lock()
# Structure: { key: [timestamp, timestamp, ...] }
_rate_limit_store: dict = defaultdict(list)

# Paths and their (max_requests, window_seconds) limits
_RATE_LIMITS = {
    '/login/':                    (5,  60),   # 5 attempts per minute per IP
    '/register/':                 (10, 60),   # 10 per minute per IP
}
# Flag submission is handled per-user in views.py


def _is_rate_limited(key: str, max_requests: int, window: int) -> bool:
    """Return True if the key has exceeded max_requests within window seconds."""
    now = time.time()
    with _rate_limit_lock:
        timestamps = _rate_limit_store[key]
        # Remove timestamps outside the window
        timestamps = [t for t in timestamps if now - t < window]
        if len(timestamps) >= max_requests:
            _rate_limit_store[key] = timestamps
            return True
        timestamps.append(now)
        _rate_limit_store[key] = timestamps
        return False


class RateLimitMiddleware(MiddlewareMixin):
    """
    Simple in-memory rate limiter for login and registration endpoints.

    For production deployments with multiple workers, replace this with
    django-ratelimit backed by Redis/Memcached.
    """

    def process_request(self, request):
        if request.method != 'POST':
            return None

        path = request.path
        limit_config = _RATE_LIMITS.get(path)
        if limit_config is None:
            return None

        max_requests, window = limit_config
        ip = get_client_ip(request)
        key = f'rl:{path}:{ip}'

        if _is_rate_limited(key, max_requests, window):
            return HttpResponse(
                "<h1 style='font-family:monospace;color:#ff9500;background:#0a0e1a;"
                "padding:2rem;'>429 — Too Many Requests<br>"
                "<small style='color:#5b8fb9'>Please wait before trying again.</small></h1>",
                status=429,
            )

        return None
