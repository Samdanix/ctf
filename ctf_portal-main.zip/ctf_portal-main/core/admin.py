from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.contrib.auth.models import User
from django.utils.html import format_html
from django.urls import reverse
from django.db.models import Count, Sum
from .models import (
    Category, Problem, Solve, Contest, 
    UserProfile, Submission, Announcement
)

# Unregister default User admin
admin.site.unregister(User)

class UserProfileInline(admin.StackedInline):
    model = UserProfile
    can_delete = False
    verbose_name_plural = 'Profile'
    fields = ('bio', 'country', 'website', 'total_points', 'rank')
    readonly_fields = ('total_points', 'rank')

@admin.register(User)
class UserAdmin(BaseUserAdmin):
    inlines = (UserProfileInline,)
    list_display = ('username', 'email', 'get_total_points', 'get_solve_count', 'is_staff', 'date_joined')
    list_filter = ('is_staff', 'is_superuser', 'is_active', 'date_joined')
    search_fields = ('username', 'email', 'first_name', 'last_name')
    
    def get_total_points(self, obj):
        total = obj.solves.aggregate(Sum('points_awarded'))['points_awarded__sum'] or 0
        return total
    get_total_points.short_description = 'Total Points'
    get_total_points.admin_order_field = 'total_points'
    
    def get_solve_count(self, obj):
        return obj.solves.count()
    get_solve_count.short_description = 'Solves'

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'description', 'get_problem_count', 'created_at')
    search_fields = ('name', 'description')
    list_filter = ('created_at',)
    
    def get_problem_count(self, obj):
        return obj.problems.count()
    get_problem_count.short_description = 'Problems'

@admin.register(Contest)
class ContestAdmin(admin.ModelAdmin):
    list_display = ('name', 'status', 'is_monthly', 'start_time', 'end_time', 'get_problem_count', 'get_participant_count')
    list_filter = ('status', 'is_monthly', 'start_time')
    search_fields = ('name', 'description')
    date_hierarchy = 'start_time'
    actions = ['update_contest_status']
    
    fieldsets = (
        ('Basic Information', {
            'fields': ('name', 'description', 'is_monthly')
        }),
        ('Schedule', {
            'fields': ('start_time', 'end_time', 'status')
        }),
    )
    
    def get_problem_count(self, obj):
        return obj.problems.count()
    get_problem_count.short_description = 'Problems'
    
    def get_participant_count(self, obj):
        return User.objects.filter(solves__problem__contest=obj).distinct().count()
    get_participant_count.short_description = 'Participants'
    
    def update_contest_status(self, request, queryset):
        for contest in queryset:
            contest.update_status()
        self.message_user(request, f"Updated status for {queryset.count()} contests.")
    update_contest_status.short_description = "Update contest status"

@admin.register(Problem)
class ProblemAdmin(admin.ModelAdmin):
    list_display = ('title', 'category', 'difficulty', 'get_points_display', 'contest', 'get_solve_count', 'is_active', 'created_at')
    list_filter = ('category', 'difficulty', 'is_active', 'contest', 'created_at')
    search_fields = ('title', 'description')
    date_hierarchy = 'created_at'
    
    fieldsets = (
        ('Basic Information', {
            'fields': ('title', 'description', 'category', 'difficulty')
        }),
        ('Flag & Points', {
            'fields': ('flag', 'initial_points', 'minimum_points'),
            'description': 'The flag will be stored securely. Points will decrease dynamically as more users solve.'
        }),
        ('Contest & Files', {
            'fields': ('contest', 'file_url', 'hint')
        }),
        ('Status', {
            'fields': ('is_active',)
        }),
    )
    
    readonly_fields = ('created_at', 'updated_at')
    
    def get_points_display(self, obj):
        current = obj.get_current_points()
        return format_html(
            '<span style="color: {};">{} pts</span> ({}→{})',
            'green' if current > obj.minimum_points else 'red',
            current,
            obj.initial_points,
            obj.minimum_points
        )
    get_points_display.short_description = 'Points'
    
    def get_solve_count(self, obj):
        count = obj.get_solve_count()
        return format_html(
            '<a href="{}?problem__id__exact={}">{} solves</a>',
            reverse('admin:core_solve_changelist'),
            obj.id,
            count
        )
    get_solve_count.short_description = 'Solves'
    
    def save_model(self, request, obj, form, change):
        # Set points if not set
        if not obj.minimum_points:
            obj.minimum_points = obj.initial_points // 2
        super().save_model(request, obj, form, change)

@admin.register(Solve)
class SolveAdmin(admin.ModelAdmin):
    list_display = ('user', 'problem', 'points_awarded', 'solved_at')
    list_filter = ('solved_at', 'problem__category', 'problem__contest')
    search_fields = ('user__username', 'problem__title')
    date_hierarchy = 'solved_at'
    readonly_fields = ('user', 'problem', 'points_awarded', 'solved_at')
    
    def has_add_permission(self, request):
        return False
    
    def has_change_permission(self, request, obj=None):
        return False

@admin.register(Submission)
class SubmissionAdmin(admin.ModelAdmin):
    list_display = ('user', 'problem', 'is_correct', 'submitted_at', 'ip_address')
    list_filter = ('is_correct', 'submitted_at', 'problem__category')
    search_fields = ('user__username', 'problem__title', 'ip_address')
    date_hierarchy = 'submitted_at'
    readonly_fields = ('user', 'problem', 'submitted_flag', 'is_correct', 'submitted_at', 'ip_address')
    
    def has_add_permission(self, request):
        return False
    
    def has_change_permission(self, request, obj=None):
        return False

@admin.register(Announcement)
class AnnouncementAdmin(admin.ModelAdmin):
    list_display = ('title', 'created_by', 'is_active', 'created_at')
    list_filter = ('is_active', 'created_at')
    search_fields = ('title', 'content')
    date_hierarchy = 'created_at'
    
    def save_model(self, request, obj, form, change):
        if not change:
            obj.created_by = request.user
        super().save_model(request, obj, form, change)

@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'total_points', 'rank', 'country', 'created_at')
    list_filter = ('country', 'created_at')
    search_fields = ('user__username', 'bio', 'country')
    readonly_fields = ('total_points', 'rank', 'created_at')

# Customize admin site
admin.site.site_header = "UAP Cyber Forge Administration"
admin.site.site_title = "Cyber Forge Admin"
admin.site.index_title = "Welcome to UAP Cyber Forge Admin Panel"
