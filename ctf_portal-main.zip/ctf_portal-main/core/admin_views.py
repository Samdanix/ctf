import os
import ipaddress

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.admin.views.decorators import staff_member_required as _staff_required
from django.contrib.auth import authenticate, login as auth_login
from django.contrib import messages
from django.db.models import Count, Sum
from django.utils import timezone
from django.utils.html import format_html, escape
from django.utils.http import url_has_allowed_host_and_scheme
from .models import (
    Problem, Category, Contest, User, Solve,
    Submission, Announcement, UserProfile, BlockedIP
)

# Re-export staff_member_required pointing at our custom admin login URL
_ADMIN_LOGIN = '/secure-mangement-core-9fA7xP3-secure-panel-AlphaZero-2026/login/'

def staff_member_required(view_func):
    """Wrapper that redirects to the custom admin login instead of /accounts/login/."""
    return _staff_required(view_func, login_url=_ADMIN_LOGIN)

# Allowed file extensions for challenge uploads
_ALLOWED_EXTENSIONS = {
    '.zip', '.tar', '.gz', '.7z',
    '.pdf', '.txt', '.png', '.jpg', '.jpeg',
    '.pcap', '.pcapng', '.bin', '.elf', '.exe',
    '.py', '.c', '.cpp', '.js', '.html',
}

def _safe_activity_message(template: str, **kwargs) -> str:
    """
    Build an activity log message with HTML-escaped values.
    Uses format_html so user-supplied strings cannot inject markup.
    """
    return format_html(template, **{k: escape(str(v)) for k, v in kwargs.items()})


def _validate_upload(uploaded_file):
    """
    Validate an uploaded challenge file.
    Returns (True, None) on success or (False, error_message) on failure.
    """
    if not uploaded_file:
        return True, None

    name = uploaded_file.name
    ext = os.path.splitext(name)[1].lower()

    if ext not in _ALLOWED_EXTENSIONS:
        return False, (
            f'File type "{ext}" is not allowed. '
            f'Allowed types: {", ".join(sorted(_ALLOWED_EXTENSIONS))}'
        )

    # 50 MB hard limit
    if uploaded_file.size > 52_428_800:
        return False, 'File size exceeds the 50 MB limit.'

    return True, None


# ─────────────────────────────────────────────────────────────────────────────
# Admin login
# ─────────────────────────────────────────────────────────────────────────────

def admin_login(request):
    """
    Dedicated admin login page.
    Only staff/superusers are allowed through; everyone else gets an error.
    """
    # Already authenticated staff → go straight to dashboard
    if request.user.is_authenticated and request.user.is_staff:
        return redirect('custom_admin_dashboard')

    from django.contrib.auth.forms import AuthenticationForm
    from core.middleware import get_client_ip, _is_rate_limited

    error = None

    if request.method == 'POST':
        ip = get_client_ip(request)
        rate_key = f'admin_login:{ip}'

        # 5 attempts per minute per IP
        if _is_rate_limited(rate_key, max_requests=5, window=60):
            error = 'Too many login attempts. Please wait before trying again.'
        else:
            form = AuthenticationForm(request, data=request.POST)
            if form.is_valid():
                user = form.get_user()
                if user.is_staff or user.is_superuser:
                    auth_login(request, user)
                    next_url = request.POST.get('next', '')
                    if next_url and url_has_allowed_host_and_scheme(
                        url=next_url,
                        allowed_hosts={request.get_host()},
                        require_https=request.is_secure(),
                    ):
                        return redirect(next_url)
                    return redirect('custom_admin_dashboard')
                else:
                    error = 'Access denied. Administrator privileges required.'
            else:
                error = 'Invalid credentials. Please try again.'
    else:
        form = AuthenticationForm(request)

    # Build a minimal form-like object so the template can show field errors
    class _Form:
        def __init__(self, f, err):
            self.non_field_errors = type('E', (), {'as_text': lambda s: err or '', '__bool__': lambda s: bool(err)})()
            self.username = f['username']
            self.password = f['password']

    ctx = {
        'form': _Form(form, error) if error else form,
        'next': request.GET.get('next', request.POST.get('next', '')),
    }
    return render(request, 'admin/admin_login.html', ctx)

@staff_member_required
def admin_dashboard(request):
    """Custom admin dashboard"""
    # Stats
    total_users = User.objects.count()
    total_challenges = Problem.objects.filter(is_active=True).count()
    active_contests = Contest.objects.filter(status='active').count()
    total_solves = Solve.objects.count()
    
    # Category breakdown
    category_stats = Problem.objects.values('category__name').annotate(
        count=Count('id')
    ).order_by('-count')[:5]
    
    # Difficulty breakdown
    difficulty_stats = Problem.objects.values('difficulty').annotate(
        count=Count('id')
    )
    
    # Recent activity (last 10 items)
    recent_submissions = Submission.objects.select_related(
        'user', 'problem'
    ).order_by('-submitted_at')[:5]
    
    recent_solves = Solve.objects.select_related(
        'user', 'problem'
    ).order_by('-solved_at')[:5]
    
    recent_users = User.objects.order_by('-date_joined')[:5]
    
    recent_contests = Contest.objects.order_by('-created_at')[:3]
    
    recent_problems = Problem.objects.order_by('-created_at')[:3]
    
    # Combine and sort activities
    activities = []
    
    for sub in recent_submissions:
        activities.append({
            'time': sub.submitted_at,
            'type': 'submission',
            'color': 'green' if sub.is_correct else 'red',
            'message': _safe_activity_message(
                "{status} flag from <em>{user}</em> on <em>{problem}</em>",
                status='Correct' if sub.is_correct else 'Failed',
                user=sub.user.username,
                problem=sub.problem.title,
            )
        })
    
    for solve in recent_solves:
        activities.append({
            'time': solve.solved_at,
            'type': 'solve',
            'color': 'amber',
            'message': _safe_activity_message(
                "Challenge <em>{problem}</em> solved by <em>{user}</em> — {pts} pts",
                problem=solve.problem.title,
                user=solve.user.username,
                pts=solve.points_awarded,
            )
        })
    
    for user in recent_users:
        activities.append({
            'time': user.date_joined,
            'type': 'user',
            'color': 'cyan',
            'message': _safe_activity_message(
                "New user <em>{user}</em> registered",
                user=user.username,
            )
        })
    
    for contest in recent_contests:
        activities.append({
            'time': contest.created_at,
            'type': 'contest',
            'color': 'green',
            'message': _safe_activity_message(
                "Contest <em>{name}</em> created",
                name=contest.name,
            )
        })
    
    for problem in recent_problems:
        activities.append({
            'time': problem.created_at,
            'type': 'problem',
            'color': 'amber',
            'message': _safe_activity_message(
                "Challenge <em>{title}</em> added — {pts} pts",
                title=problem.title,
                pts=problem.initial_points,
            )
        })
    
    activities.sort(key=lambda x: x['time'], reverse=True)
    activities = activities[:10]
    
    context = {
        'total_users': total_users,
        'total_challenges': total_challenges,
        'active_contests': active_contests,
        'total_solves': total_solves,
        'category_stats': category_stats,
        'difficulty_stats': difficulty_stats,
        'activities': activities,
    }
    
    return render(request, 'admin/custom_dashboard.html', context)

@staff_member_required
def admin_challenges(request):
    """Manage challenges"""
    challenges = Problem.objects.select_related('category', 'contest').annotate(
        solve_count=Count('solves')
    ).order_by('-created_at')
    
    context = {
        'challenges': challenges,
    }
    
    return render(request, 'admin/custom_challenges.html', context)

@staff_member_required
def admin_contests(request):
    """Manage contests"""
    # Update contest statuses
    for contest in Contest.objects.all():
        contest.update_status()
    
    contests = Contest.objects.annotate(
        problem_count=Count('problems')
    ).order_by('-start_time')
    
    context = {
        'contests': contests,
    }
    
    return render(request, 'admin/custom_contests.html', context)

@staff_member_required
def admin_users(request):
    """Manage users"""
    users = User.objects.annotate(
        total_points=Sum('solves__points_awarded'),
        solve_count=Count('solves')
    ).order_by('-date_joined')

    # Build dict: user_id -> latest ip_address
    # Use Python-level dedup so it works on SQLite and PostgreSQL alike
    latest_ips = {}
    seen = set()
    for sub in (
        Submission.objects
        .exclude(ip_address__isnull=True)
        .exclude(ip_address='')
        .order_by('-submitted_at')
        .values('user_id', 'ip_address')
    ):
        uid = sub['user_id']
        if uid not in seen:
            latest_ips[uid] = sub['ip_address']
            seen.add(uid)

    # Get set of currently blocked IPs for badge display
    blocked_ips = set(BlockedIP.objects.values_list('ip_address', flat=True))

    user_list = []
    for user in users:
        ip = latest_ips.get(user.id)
        user_list.append({
            'user': user,
            'latest_ip': ip,
            'ip_blocked': ip in blocked_ips if ip else False,
        })

    context = {
        'user_list': user_list,
        'users': users,
    }

    return render(request, 'admin/custom_users.html', context)

@staff_member_required
def admin_submissions(request):
    """View all submissions"""
    submissions = Submission.objects.select_related(
        'user', 'problem'
    ).order_by('-submitted_at')[:100]
    
    context = {
        'submissions': submissions,
    }
    
    return render(request, 'admin/custom_submissions.html', context)

@staff_member_required
def admin_activity_log(request):
    """Full activity log"""
    # Get all activities
    activities = []
    
    submissions = Submission.objects.select_related('user', 'problem').order_by('-submitted_at')[:50]
    for sub in submissions:
        activities.append({
            'time': sub.submitted_at,
            'color': 'green' if sub.is_correct else 'red',
            'message': _safe_activity_message(
                "{status} flag from <em>{user}</em> on <em>{problem}</em>",
                status='Correct' if sub.is_correct else 'Failed',
                user=sub.user.username,
                problem=sub.problem.title,
            )
        })
    
    solves = Solve.objects.select_related('user', 'problem').order_by('-solved_at')[:50]
    for solve in solves:
        activities.append({
            'time': solve.solved_at,
            'color': 'amber',
            'message': _safe_activity_message(
                "Challenge <em>{problem}</em> solved by <em>{user}</em> — {pts} pts",
                problem=solve.problem.title,
                user=solve.user.username,
                pts=solve.points_awarded,
            )
        })
    
    users = User.objects.order_by('-date_joined')[:50]
    for user in users:
        activities.append({
            'time': user.date_joined,
            'color': 'cyan',
            'message': _safe_activity_message(
                "New user <em>{user}</em> registered",
                user=user.username,
            )
        })
    
    contests = Contest.objects.order_by('-created_at')[:30]
    for contest in contests:
        activities.append({
            'time': contest.created_at,
            'color': 'green',
            'message': _safe_activity_message(
                "Contest <em>{name}</em> created",
                name=contest.name,
            )
        })
    
    problems = Problem.objects.order_by('-created_at')[:30]
    for problem in problems:
        activities.append({
            'time': problem.created_at,
            'color': 'amber',
            'message': _safe_activity_message(
                "Challenge <em>{title}</em> added — {pts} pts",
                title=problem.title,
                pts=problem.initial_points,
            )
        })
    
    activities.sort(key=lambda x: x['time'], reverse=True)
    activities = activities[:100]
    
    context = {
        'activities': activities,
    }
    
    return render(request, 'admin/custom_activity_log.html', context)

@staff_member_required
def admin_new_challenge(request):
    """Create new challenge"""
    if request.method == 'POST':
        try:
            # Handle form submission
            title = request.POST.get('title')
            description = request.POST.get('description')
            category_id = request.POST.get('category')
            difficulty = request.POST.get('difficulty')
            points = request.POST.get('points')
            flag = request.POST.get('flag')
            author = request.POST.get('author', 'Admin')
            hint = request.POST.get('hint', '')
            file_url = request.POST.get('file_url', '')
            max_attempts = request.POST.get('max_attempts', '0')
            scoring_type = request.POST.get('scoring_type', 'static')
            minimum_points = request.POST.get('minimum_points', '0')
            decay_value = request.POST.get('decay_value', '10')
            
            if not all([title, description, category_id, difficulty, points, flag]):
                messages.error(request, 'Please fill in all required fields.')
                return redirect('custom_admin_new_challenge')
            
            category = Category.objects.get(id=category_id)
            
            # Set minimum_points based on scoring type
            if scoring_type == 'static':
                min_pts = int(points)  # For static, min = initial
            else:
                min_pts = int(minimum_points) if minimum_points else int(points) // 2
            
            # Create problem instance
            problem = Problem(
                title=title,
                description=description,
                category=category,
                difficulty=difficulty,
                flag=flag,
                initial_points=int(points),
                minimum_points=min_pts,
                points=int(points),
                author=author,
                hint=hint,
                file_url=file_url,
                max_attempts=int(max_attempts),
                scoring_type=scoring_type,
                decay_value=int(decay_value),
                is_active=True
            )
            
            # Handle file upload
            if 'challenge_file' in request.FILES:
                uploaded = request.FILES['challenge_file']
                ok, err = _validate_upload(uploaded)
                if not ok:
                    messages.error(request, err)
                    return redirect('custom_admin_new_challenge')
                problem.challenge_file = uploaded
            
            problem.save()
            
            messages.success(request, f'Challenge "{title}" created successfully!')
            return redirect('custom_admin_challenges')
        except Exception as e:
            messages.error(request, f'Error creating challenge: {str(e)}')
            return redirect('custom_admin_new_challenge')
    
    categories = Category.objects.all()
    
    context = {
        'categories': categories,
    }
    
    return render(request, 'admin/custom_new_challenge.html', context)

@staff_member_required
def admin_new_contest(request):
    """Create new contest"""
    if request.method == 'POST':
        try:
            name = request.POST.get('name')
            description = request.POST.get('description')
            start_time = request.POST.get('start_time')
            end_time = request.POST.get('end_time')
            is_monthly = request.POST.get('is_monthly') == 'on'
            
            if not all([name, description, start_time, end_time]):
                messages.error(request, 'Please fill in all required fields.')
                return redirect('custom_admin_new_contest')
            
            from django.utils.dateparse import parse_datetime
            parsed_start = parse_datetime(start_time)
            parsed_end = parse_datetime(end_time)
            if parsed_start and parsed_end and parsed_end <= parsed_start:
                messages.error(request, 'End time must be after start time.')
                return redirect('custom_admin_new_contest')
            
            contest = Contest.objects.create(
                name=name,
                description=description,
                start_time=start_time,
                end_time=end_time,
                is_monthly=is_monthly,
                status='upcoming'
            )
            
            contest.update_status()
            
            messages.success(request, f'Contest "{name}" created successfully!')
            return redirect('custom_admin_contests')
        except Exception as e:
            messages.error(request, f'Error creating contest: {str(e)}')
            return redirect('custom_admin_new_contest')
    
    return render(request, 'admin/custom_new_contest.html')

@staff_member_required
def admin_announce(request):
    """Create and manage announcements"""
    if request.method == 'POST':
        try:
            title = request.POST.get('title')
            content = request.POST.get('content')
            
            if not all([title, content]):
                messages.error(request, 'Please fill in all required fields.')
                return redirect('custom_admin_announce')
            
            announcement = Announcement.objects.create(
                title=title,
                content=content,
                created_by=request.user,
                is_active=True
            )
            
            messages.success(request, 'Announcement posted successfully!')
            return redirect('custom_admin_announce')
        except Exception as e:
            messages.error(request, f'Error posting announcement: {str(e)}')
            return redirect('custom_admin_announce')
    
    # Get all announcements
    announcements = Announcement.objects.all().order_by('-created_at')
    
    return render(request, 'admin/custom_announce.html', {
        'announcements': announcements
    })

@staff_member_required
def admin_edit_announcement(request, announcement_id):
    """Edit announcement"""
    announcement = get_object_or_404(Announcement, id=announcement_id)
    
    if request.method == 'POST':
        try:
            announcement.title = request.POST.get('title')
            announcement.content = request.POST.get('content')
            is_active = request.POST.get('is_active') == 'on'
            announcement.is_active = is_active
            announcement.save()
            
            messages.success(request, 'Announcement updated successfully!')
            return redirect('custom_admin_announce')
        except Exception as e:
            messages.error(request, f'Error updating announcement: {str(e)}')
    
    return render(request, 'admin/custom_edit_announcement.html', {
        'announcement': announcement
    })

@staff_member_required
def admin_delete_announcement(request, announcement_id):
    """Delete announcement"""
    announcement = get_object_or_404(Announcement, id=announcement_id)
    
    try:
        title = announcement.title
        announcement.delete()
        messages.success(request, f'Announcement "{title}" deleted successfully!')
    except Exception as e:
        messages.error(request, f'Error deleting announcement: {str(e)}')
    
    return redirect('custom_admin_announce')

@staff_member_required
def admin_toggle_announcement(request, announcement_id):
    """Toggle announcement active status"""
    announcement = get_object_or_404(Announcement, id=announcement_id)
    
    try:
        announcement.is_active = not announcement.is_active
        announcement.save()
        status = "activated" if announcement.is_active else "deactivated"
        messages.success(request, f'Announcement "{announcement.title}" {status}!')
    except Exception as e:
        messages.error(request, f'Error toggling announcement: {str(e)}')
    
    return redirect('custom_admin_announce')

@staff_member_required
def admin_settings(request):
    """Platform settings"""
    if request.method == 'POST':
        try:
            # Handle settings update
            messages.success(request, 'Settings updated successfully!')
            return redirect('custom_admin_settings')
        except Exception as e:
            messages.error(request, f'Error updating settings: {str(e)}')
            return redirect('custom_admin_settings')
    
    return render(request, 'admin/custom_settings.html')

@staff_member_required
def admin_delete_challenge(request, challenge_id):
    """Delete a challenge"""
    try:
        challenge = get_object_or_404(Problem, id=challenge_id)
        title = challenge.title
        challenge.delete()
        messages.success(request, f'Challenge "{title}" deleted successfully!')
    except Exception as e:
        messages.error(request, f'Error deleting challenge: {str(e)}')
    return redirect('custom_admin_challenges')

@staff_member_required
def admin_toggle_challenge(request, challenge_id):
    """Toggle challenge active status"""
    try:
        challenge = get_object_or_404(Problem, id=challenge_id)
        challenge.is_active = not challenge.is_active
        challenge.save()
        status = "activated" if challenge.is_active else "deactivated"
        messages.success(request, f'Challenge "{challenge.title}" {status}!')
    except Exception as e:
        messages.error(request, f'Error toggling challenge: {str(e)}')
    return redirect('custom_admin_challenges')

@staff_member_required
def admin_delete_contest(request, contest_id):
    """Delete a contest"""
    try:
        contest = get_object_or_404(Contest, id=contest_id)
        name = contest.name
        contest.delete()
        messages.success(request, f'Contest "{name}" deleted successfully!')
    except Exception as e:
        messages.error(request, f'Error deleting contest: {str(e)}')
    return redirect('custom_admin_contests')

@staff_member_required
def admin_end_contest(request, contest_id):
    """End a contest"""
    try:
        contest = get_object_or_404(Contest, id=contest_id)
        contest.status = 'ended'
        contest.end_time = timezone.now()
        contest.save()
        messages.success(request, f'Contest "{contest.name}" ended successfully!')
    except Exception as e:
        messages.error(request, f'Error ending contest: {str(e)}')
    return redirect('custom_admin_contests')


@staff_member_required
def admin_freeze_leaderboard(request, contest_id):
    """Freeze the contest leaderboard at the current moment (or a specified time)."""
    contest = get_object_or_404(Contest, id=contest_id)
    try:
        # Optional: admin can supply a custom freeze datetime via POST
        custom_time = request.POST.get('freeze_time', '').strip()
        if custom_time:
            from django.utils.dateparse import parse_datetime
            ft = parse_datetime(custom_time)
            if ft is None:
                messages.error(request, 'Invalid freeze time format. Use YYYY-MM-DD HH:MM.')
                return redirect('custom_admin_view_contest', contest_id=contest_id)
        else:
            ft = timezone.now()

        contest.leaderboard_frozen = True
        contest.freeze_time = ft
        contest.save()
        messages.success(
            request,
            f'Leaderboard frozen at {ft.strftime("%Y-%m-%d %H:%M:%S UTC")}. '
            'Participants now see standings as of that moment.'
        )
    except Exception as e:
        messages.error(request, f'Error freezing leaderboard: {str(e)}')
    return redirect('custom_admin_view_contest', contest_id=contest_id)


@staff_member_required
def admin_unfreeze_leaderboard(request, contest_id):
    """Unfreeze the contest leaderboard (reveal real-time standings)."""
    contest = get_object_or_404(Contest, id=contest_id)
    try:
        contest.leaderboard_frozen = False
        contest.freeze_time = None
        contest.save()
        messages.success(request, f'Leaderboard for "{contest.name}" is now live again.')
    except Exception as e:
        messages.error(request, f'Error unfreezing leaderboard: {str(e)}')
    return redirect('custom_admin_view_contest', contest_id=contest_id)

@staff_member_required
def admin_ban_user(request, user_id):
    """Ban/unban a user"""
    try:
        user = get_object_or_404(User, id=user_id)
        if user.is_staff:
            messages.error(request, 'Cannot ban admin users!')
            return redirect('custom_admin_users')
        
        user.is_active = not user.is_active
        user.save()
        status = "unbanned" if user.is_active else "banned"
        messages.success(request, f'User "{user.username}" {status}!')
    except Exception as e:
        messages.error(request, f'Error banning user: {str(e)}')
    return redirect('custom_admin_users')

@staff_member_required
def admin_view_challenge(request, challenge_id):
    """View challenge details"""
    challenge = get_object_or_404(Problem, id=challenge_id)
    solve_count = challenge.get_solve_count()
    
    context = {
        'challenge': challenge,
        'solve_count': solve_count,
    }
    
    return render(request, 'admin/custom_view_challenge.html', context)

@staff_member_required
def admin_edit_challenge(request, challenge_id):
    """Edit challenge"""
    challenge = get_object_or_404(Problem, id=challenge_id)
    
    if request.method == 'POST':
        try:
            # Get form data
            title = request.POST.get('title')
            description = request.POST.get('description')
            category_id = request.POST.get('category')
            difficulty = request.POST.get('difficulty')
            points = request.POST.get('points')
            flag = request.POST.get('flag')
            author = request.POST.get('author', 'Admin')
            hint = request.POST.get('hint', '')
            file_url = request.POST.get('file_url', '')
            max_attempts = request.POST.get('max_attempts', '0')
            is_active = request.POST.get('is_active') == 'true'
            contest_id = request.POST.get('contest')
            scoring_type = request.POST.get('scoring_type', 'static')
            minimum_points = request.POST.get('minimum_points', '0')
            decay_value = request.POST.get('decay_value', '10')
            
            if not all([title, description, category_id, difficulty, points, flag]):
                messages.error(request, 'Please fill in all required fields.')
                return redirect('custom_admin_edit_challenge', challenge_id=challenge_id)
            
            # Set minimum_points based on scoring type
            if scoring_type == 'static':
                min_pts = int(points)  # For static, min = initial
            else:
                min_pts = int(minimum_points) if minimum_points else int(points) // 2
            
            # Update challenge
            challenge.title = title
            challenge.description = description
            challenge.category = Category.objects.get(id=category_id)
            challenge.difficulty = difficulty
            challenge.flag = flag
            challenge.initial_points = int(points)
            challenge.minimum_points = min_pts
            challenge.points = int(points)
            challenge.author = author
            challenge.hint = hint
            challenge.file_url = file_url
            challenge.max_attempts = int(max_attempts)
            challenge.scoring_type = scoring_type
            challenge.decay_value = int(decay_value)
            challenge.is_active = is_active
            
            # Update contest
            if contest_id:
                challenge.contest = Contest.objects.get(id=contest_id)
            else:
                challenge.contest = None
            
            # Handle file upload
            if 'challenge_file' in request.FILES:
                uploaded = request.FILES['challenge_file']
                ok, err = _validate_upload(uploaded)
                if not ok:
                    messages.error(request, err)
                    return redirect('custom_admin_edit_challenge', challenge_id=challenge_id)
                challenge.challenge_file = uploaded
            
            challenge.save()
            
            messages.success(request, f'Challenge "{title}" updated successfully!')
            return redirect('custom_admin_view_challenge', challenge_id=challenge_id)
        except Exception as e:
            messages.error(request, f'Error updating challenge: {str(e)}')
            return redirect('custom_admin_edit_challenge', challenge_id=challenge_id)
    
    categories = Category.objects.all()
    contests = Contest.objects.all()
    
    context = {
        'challenge': challenge,
        'categories': categories,
        'contests': contests,
    }
    
    return render(request, 'admin/custom_edit_challenge.html', context)

@staff_member_required
def admin_view_contest(request, contest_id):
    """View contest details and manage challenges"""
    contest = get_object_or_404(Contest, id=contest_id)
    challenges = Problem.objects.filter(contest=contest).select_related('category').annotate(
        solve_count=Count('solves')
    ).order_by('-created_at')
    
    context = {
        'contest': contest,
        'challenges': challenges,
    }
    
    return render(request, 'admin/custom_view_contest.html', context)

@staff_member_required
def admin_contest_add_challenge(request, contest_id):
    """Add a new challenge to a contest"""
    contest = get_object_or_404(Contest, id=contest_id)
    
    if request.method == 'POST':
        try:
            # Handle form submission
            title = request.POST.get('title')
            description = request.POST.get('description')
            category_id = request.POST.get('category')
            difficulty = request.POST.get('difficulty')
            points = request.POST.get('points')
            flag = request.POST.get('flag')
            author = request.POST.get('author', 'Admin')
            hint = request.POST.get('hint', '')
            file_url = request.POST.get('file_url', '')
            max_attempts = request.POST.get('max_attempts', '0')
            scoring_type = request.POST.get('scoring_type', 'static')
            minimum_points = request.POST.get('minimum_points', '0')
            decay_value = request.POST.get('decay_value', '10')
            
            if not all([title, description, category_id, difficulty, points, flag]):
                messages.error(request, 'Please fill in all required fields.')
                return redirect('custom_admin_contest_add_challenge', contest_id=contest_id)
            
            category = Category.objects.get(id=category_id)
            
            # Set minimum_points based on scoring type
            if scoring_type == 'static':
                min_pts = int(points)  # For static, min = initial
            else:
                min_pts = int(minimum_points) if minimum_points else int(points) // 2
            
            # Create problem instance for this contest
            problem = Problem(
                title=title,
                description=description,
                category=category,
                difficulty=difficulty,
                flag=flag,
                initial_points=int(points),
                minimum_points=min_pts,
                points=int(points),
                author=author,
                hint=hint,
                file_url=file_url,
                max_attempts=int(max_attempts),
                scoring_type=scoring_type,
                decay_value=int(decay_value),
                contest=contest,  # Assign to contest
                is_active=True
            )
            
            # Handle file upload
            if 'challenge_file' in request.FILES:
                uploaded = request.FILES['challenge_file']
                ok, err = _validate_upload(uploaded)
                if not ok:
                    messages.error(request, err)
                    return redirect('custom_admin_contest_add_challenge', contest_id=contest_id)
                problem.challenge_file = uploaded
            
            problem.save()
            
            messages.success(request, f'Challenge "{title}" added to contest "{contest.name}"!')
            return redirect('custom_admin_view_contest', contest_id=contest_id)
        except Exception as e:
            messages.error(request, f'Error creating challenge: {str(e)}')
            return redirect('custom_admin_contest_add_challenge', contest_id=contest_id)
    
    categories = Category.objects.all()
    
    context = {
        'contest': contest,
        'categories': categories,
    }
    
    return render(request, 'admin/custom_contest_add_challenge.html', context)

@staff_member_required
def admin_contest_remove_challenge(request, contest_id, challenge_id):
    """Remove a challenge from a contest"""
    try:
        contest = get_object_or_404(Contest, id=contest_id)
        challenge = get_object_or_404(Problem, id=challenge_id, contest=contest)
        title = challenge.title
        
        # Remove from contest (set to None)
        challenge.contest = None
        challenge.save()
        
        messages.success(request, f'Challenge "{title}" removed from contest "{contest.name}"!')
    except Exception as e:
        messages.error(request, f'Error removing challenge: {str(e)}')
    
    return redirect('custom_admin_view_contest', contest_id=contest_id)

@staff_member_required
def admin_contest_scoreboard(request, contest_id):
    """Contest scoreboard and analytics for cheating detection"""
    from django.db.models import Q, Count, Sum, Avg, Min
    from datetime import timedelta
    
    contest = get_object_or_404(Contest, id=contest_id)
    contest_challenges = Problem.objects.filter(contest=contest)
    
    # Get all users who participated in this contest (exclude superusers)
    participant_ids = Solve.objects.filter(
        problem__contest=contest
    ).values_list('user_id', flat=True).distinct()
    
    participants = User.objects.filter(id__in=participant_ids, is_superuser=False)
    
    # Build scoreboard
    scoreboard = []
    for user in participants:
        # Get solves for this contest
        user_solves = Solve.objects.filter(
            user=user,
            problem__contest=contest
        ).select_related('problem')
        
        # Get submissions for this contest
        user_submissions = Submission.objects.filter(
            user=user,
            problem__contest=contest
        )
        
        total_score = user_solves.aggregate(Sum('points_awarded'))['points_awarded__sum'] or 0
        solve_count = user_solves.count()
        total_submissions = user_submissions.count()
        correct_submissions = user_submissions.filter(is_correct=True).count()
        
        success_rate = round((correct_submissions / total_submissions * 100) if total_submissions > 0 else 0, 1)
        
        # Get last solve time
        last_solve = user_solves.order_by('-solved_at').first()
        last_solve_time = last_solve.solved_at if last_solve else None
        
        # Get IP address (from most recent submission)
        recent_sub = user_submissions.order_by('-submitted_at').first()
        ip_address = recent_sub.ip_address if recent_sub else None
        
        # Detect suspicious activity
        suspicious = False
        if success_rate > 80 and total_submissions > 5:  # Very high success rate
            suspicious = True
        
        # Calculate average solve time
        solve_times = []
        for solve in user_solves:
            # Get first submission time for this problem
            first_sub = Submission.objects.filter(
                user=user,
                problem=solve.problem
            ).order_by('submitted_at').first()
            
            if first_sub:
                time_diff = (solve.solved_at - first_sub.submitted_at).total_seconds() / 60
                solve_times.append(time_diff)
        
        avg_solve_time = sum(solve_times) / len(solve_times) if solve_times else 0
        
        # Fast solves detection (< 2 minutes average)
        if avg_solve_time < 2 and solve_count > 2:
            suspicious = True
        
        scoreboard.append({
            'user_id': user.id,
            'username': user.username,
            'score': total_score,
            'solve_count': solve_count,
            'total_submissions': total_submissions,
            'success_rate': success_rate,
            'last_solve_time': last_solve_time,
            'ip_address': ip_address,
            'suspicious': suspicious,
            'avg_solve_time': round(avg_solve_time, 1),
        })
    
    # Sort by score (descending), then by last solve time (ascending)
    scoreboard.sort(key=lambda x: (-x['score'], x['last_solve_time'] or timezone.now()))
    
    # Add ranks
    for i, participant in enumerate(scoreboard, 1):
        participant['rank'] = i
    
    # Statistics
    total_participants = len(scoreboard)
    total_solves = sum(p['solve_count'] for p in scoreboard)
    total_submissions = sum(p['total_submissions'] for p in scoreboard)
    success_rate = round((total_solves / total_submissions * 100) if total_submissions > 0 else 0, 1)
    avg_solves_per_user = round(total_solves / total_participants, 1) if total_participants > 0 else 0
    
    # All submissions for this contest
    all_submissions = Submission.objects.filter(
        problem__contest=contest
    ).select_related('user', 'problem').order_by('-submitted_at')[:100]
    
    # Add points_awarded to submissions
    for sub in all_submissions:
        if sub.is_correct:
            solve = Solve.objects.filter(user=sub.user, problem=sub.problem).first()
            sub.points_awarded = solve.points_awarded if solve else 0
        else:
            sub.points_awarded = 0
    
    # Suspicious users
    suspicious_users = []
    for participant in scoreboard:
        if participant['suspicious']:
            suspicious_users.append({
                'username': participant['username'],
                'score': participant['score'],
                'solve_count': participant['solve_count'],
                'total_submissions': participant['total_submissions'],
                'success_rate': participant['success_rate'],
                'avg_solve_time': f"{participant['avg_solve_time']} min",
                'high_success_rate': participant['success_rate'] > 80,
                'fast_solves': participant['avg_solve_time'] < 2 and participant['solve_count'] > 2,
                'same_ip': False,  # Will be set below
            })
    
    # Challenge statistics
    challenge_stats = []
    for challenge in contest_challenges:
        solves = Solve.objects.filter(problem=challenge).count()
        submissions = Submission.objects.filter(problem=challenge).count()
        success_rate = round((solves / submissions * 100) if submissions > 0 else 0, 1)
        
        # First blood
        first_solve = Solve.objects.filter(problem=challenge).order_by('solved_at').first()
        first_blood = first_solve.user.username if first_solve else None
        
        # Average solve time
        solve_times = []
        for solve in Solve.objects.filter(problem=challenge):
            first_sub = Submission.objects.filter(
                user=solve.user,
                problem=challenge
            ).order_by('submitted_at').first()
            
            if first_sub:
                time_diff = (solve.solved_at - first_sub.submitted_at).total_seconds() / 60
                solve_times.append(time_diff)
        
        avg_solve_time = f"{round(sum(solve_times) / len(solve_times), 1)} min" if solve_times else None
        
        challenge_stats.append({
            'title': challenge.title,
            'category': challenge.category.name,
            'solves': solves,
            'submissions': submissions,
            'success_rate': success_rate,
            'first_blood': first_blood,
            'avg_solve_time': avg_solve_time,
        })
    
    # IP address analysis
    ip_data = {}
    for sub in Submission.objects.filter(problem__contest=contest).select_related('user'):
        if sub.ip_address:
            if sub.ip_address not in ip_data:
                ip_data[sub.ip_address] = {
                    'users': set(),
                    'submissions': 0,
                }
            ip_data[sub.ip_address]['users'].add(sub.user.username)
            ip_data[sub.ip_address]['submissions'] += 1
    
    ip_analysis = []
    for ip, data in ip_data.items():
        user_count = len(data['users'])
        ip_analysis.append({
            'ip_address': ip,
            'user_count': user_count,
            'submission_count': data['submissions'],
            'usernames': ', '.join(sorted(data['users'])),
        })
        
        # Flag users with shared IP
        if user_count > 1:
            for user in suspicious_users:
                if user['username'] in data['users']:
                    user['same_ip'] = True
    
    # Sort IP analysis by user count (descending)
    ip_analysis.sort(key=lambda x: -x['user_count'])
    
    context = {
        'contest': contest,
        'scoreboard': scoreboard,
        'total_participants': total_participants,
        'total_solves': total_solves,
        'total_submissions': total_submissions,
        'success_rate': success_rate,
        'avg_solves_per_user': avg_solves_per_user,
        'all_submissions': all_submissions,
        'suspicious_users': suspicious_users,
        'challenge_stats': challenge_stats,
        'ip_analysis': ip_analysis,
    }
    
    return render(request, 'admin/custom_contest_scoreboard.html', context)


# ─────────────────────────────────────────────
#  User management helpers
# ─────────────────────────────────────────────

def _get_client_ip(request):
    """Extract real client IP (same logic as middleware)."""
    xff = request.META.get('HTTP_X_FORWARDED_FOR')
    if xff:
        return xff.split(',')[0].strip()
    return request.META.get('REMOTE_ADDR', '')


@staff_member_required
def admin_delete_user(request, user_id):
    """Permanently delete a user and all their data."""
    try:
        user = get_object_or_404(User, id=user_id)
        if user.is_staff:
            messages.error(request, 'Cannot delete admin users!')
            return redirect('custom_admin_users')
        username = user.username
        user.delete()
        messages.success(request, f'User "{username}" deleted permanently.')
    except Exception as e:
        messages.error(request, f'Error deleting user: {str(e)}')
    return redirect('custom_admin_users')


@staff_member_required
def admin_block_user_ip(request, user_id):
    """Block the most-recent submission IP of a user."""
    try:
        user = get_object_or_404(User, id=user_id)
        if user.is_staff:
            messages.error(request, 'Cannot block admin users!')
            return redirect('custom_admin_users')

        # Find the most recent IP used by this user
        recent_sub = (
            Submission.objects.filter(user=user)
            .exclude(ip_address__isnull=True)
            .exclude(ip_address='')
            .order_by('-submitted_at')
            .first()
        )

        if not recent_sub or not recent_sub.ip_address:
            messages.warning(
                request,
                f'No submission IP found for "{user.username}". '
                'They have not submitted any flags yet.'
            )
            return redirect('custom_admin_users')

        ip = recent_sub.ip_address
        reason = request.POST.get('reason', 'Blocked by admin') or 'Blocked by admin'

        blocked, created = BlockedIP.objects.get_or_create(
            ip_address=ip,
            defaults={'blocked_by': request.user, 'reason': reason},
        )
        if created:
            messages.success(
                request,
                f'IP {ip} (from user "{user.username}") has been blocked.'
            )
        else:
            messages.info(request, f'IP {ip} was already blocked.')
    except Exception as e:
        messages.error(request, f'Error blocking IP: {str(e)}')
    return redirect('custom_admin_users')


# ─────────────────────────────────────────────
#  Blocked IP management
# ─────────────────────────────────────────────

@staff_member_required
def admin_blocked_ips(request):
    """List all blocked IPs."""
    blocked = BlockedIP.objects.select_related('blocked_by').all()

    # Enrich with known usernames that used each IP
    ip_to_users = {}
    for sub in Submission.objects.exclude(ip_address__isnull=True).exclude(ip_address='').select_related('user'):
        ip_to_users.setdefault(sub.ip_address, set()).add(sub.user.username)

    blocked_list = []
    for entry in blocked:
        blocked_list.append({
            'obj': entry,
            'known_users': ', '.join(sorted(ip_to_users.get(entry.ip_address, []))),
        })

    context = {
        'blocked_list': blocked_list,
        'total': len(blocked_list),
    }
    return render(request, 'admin/custom_blocked_ips.html', context)


@staff_member_required
def admin_block_ip_manual(request):
    """Manually block an IP address."""
    if request.method == 'POST':
        ip = request.POST.get('ip_address', '').strip()
        reason = request.POST.get('reason', 'Blocked by admin').strip() or 'Blocked by admin'

        if not ip:
            messages.error(request, 'Please provide an IP address.')
            return redirect('custom_admin_blocked_ips')

        # Basic validation
        import ipaddress
        try:
            ipaddress.ip_address(ip)
        except ValueError:
            messages.error(request, f'"{ip}" is not a valid IP address.')
            return redirect('custom_admin_blocked_ips')

        blocked, created = BlockedIP.objects.get_or_create(
            ip_address=ip,
            defaults={'blocked_by': request.user, 'reason': reason},
        )
        if created:
            messages.success(request, f'IP {ip} blocked successfully.')
        else:
            messages.info(request, f'IP {ip} was already blocked.')
    return redirect('custom_admin_blocked_ips')


@staff_member_required
def admin_unblock_ip(request, blocked_id):
    """Remove an IP from the block list."""
    try:
        entry = get_object_or_404(BlockedIP, id=blocked_id)
        ip = entry.ip_address
        entry.delete()
        messages.success(request, f'IP {ip} has been unblocked.')
    except Exception as e:
        messages.error(request, f'Error unblocking IP: {str(e)}')
    return redirect('custom_admin_blocked_ips')
