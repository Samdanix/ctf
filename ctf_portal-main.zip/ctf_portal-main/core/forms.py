from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
import re


class CustomUserCreationForm(UserCreationForm):
    full_name = forms.CharField(
        required=True,
        max_length=100,
        help_text='Full name required',
        widget=forms.TextInput(attrs={'placeholder': 'Enter your full name'})
    )
    
    email = forms.EmailField(
        required=True,
        help_text='Must be UAP Mail: XXXXXXXX@uap-bd.edu',
        widget=forms.EmailInput(attrs={'placeholder': '12345678@uap-bd.edu'})
    )
    
    phone = forms.CharField(
        required=True,
        max_length=11,
        help_text='11 digits required',
        widget=forms.TextInput(attrs={'placeholder': '01XXXXXXXXX'})
    )
    
    class Meta:
        model = User
        fields = ('username', 'full_name', 'email', 'phone', 'password1', 'password2')
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['username'].help_text = ''
        self.fields['username'].required = True
        self.fields['password1'].help_text = 'Minimum 8 characters'
        self.fields['password1'].required = True
        self.fields['password2'].help_text = ''
        self.fields['password2'].required = True
    
    def clean_full_name(self):
        full_name = self.cleaned_data.get('full_name')
        if not full_name or len(full_name.strip()) < 2:
            raise ValidationError('Please enter your full name')
        return full_name.strip()
    
    def clean_email(self):
        email = self.cleaned_data.get('email')
        pattern = r'^\d{8}@uap-bd\.edu$'
        if not re.match(pattern, email):
            raise ValidationError('Email must be in format: XXXXXXXX@uap-bd.edu')
        if User.objects.filter(email=email).exists():
            raise ValidationError('This email address is already registered.')
        return email
    
    def clean_phone(self):
        phone = self.cleaned_data.get('phone')
        phone = phone.replace(' ', '').replace('-', '')
        pattern = r'^\d{11}$'
        if not re.match(pattern, phone):
            raise ValidationError('Phone number must be exactly 11 digits')
        return phone
    
    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data['email']
        user.first_name = self.cleaned_data['full_name']
        if commit:
            user.save()
            from .models import UserProfile
            profile, created = UserProfile.objects.get_or_create(user=user)
            profile.phone = self.cleaned_data['phone']
            profile.save()
        return user
