# CTF Platform

A Django-based Capture The Flag (CTF) platform with Cloudflare Tunnel integration.

## 🚀 Quick Start with Docker

### Prerequisites

- Docker and Docker Compose installed on your VM
- Cloudflare Tunnel configured (already set up in docker-compose.yml)

### Deployment Steps

1. **Clone the repository** (if not already done):
   ```bash
   git clone <your-repo-url>
   cd <project-directory>
   ```

2. **Set up environment variables**:
   ```bash
   cp .env.example .env
   ```
   
   Edit `.env` and set a strong `SECRET_KEY`:
   ```bash
   # Generate a secret key
   python -c 'from django.core.management.utils import get_random_secret_key; print(get_random_secret_key())'
   ```

3. **Deploy using the deployment script**:
   ```bash
   chmod +x deploy.sh
   ./deploy.sh
   ```

   Or manually:
   ```bash
   docker compose build
   docker compose up -d
   docker compose exec web python manage.py migrate
   ```

4. **Create a superuser**:
   ```bash
   docker compose exec web python manage.py createsuperuser
   ```

5. **Access your platform**:
   - Public URL: https://uapcyberforge.xyz
   - Admin Panel: https://uapcyberforge.xyz/secure-mangement-core-9fA7xP3-secure-panel-AlphaZero-2026/

## 📋 Docker Commands

### View logs
```bash
docker compose logs -f          # All services
docker compose logs -f web      # Django app only
docker compose logs -f cloudflared  # Cloudflare tunnel only
```

### Restart services
```bash
docker compose restart
```

### Stop services
```bash
docker compose down
```

### Rebuild after code changes
```bash
docker compose down
docker compose build
docker compose up -d
```

### Run Django management commands
```bash
docker compose exec web python manage.py <command>
```

Examples:
```bash
# Create superuser
docker compose exec web python manage.py createsuperuser

# Run migrations
docker compose exec web python manage.py migrate

# Collect static files
docker compose exec web python manage.py collectstatic

# Update contests
docker compose exec web python manage.py update_contests

# Update leaderboard
docker compose exec web python manage.py update_leaderboard
```

## 🔧 Configuration

### Environment Variables

Edit `.env` file to configure:

- `SECRET_KEY`: Django secret key (required)
- `DEBUG`: Set to `False` in production
- `ALLOWED_HOSTS`: Comma-separated list of allowed hostnames
- `DJANGO_LOG_LEVEL`: Logging level (INFO, WARNING, ERROR)
- `CSRF_TRUSTED_ORIGINS`: Additional CSRF trusted origins (optional)
- `CORS_ALLOWED_ORIGINS`: Additional CORS allowed origins (optional)

### CSRF & CORS Configuration

The platform is pre-configured for your domains:
- **CSRF Trusted Origins**: `https://uapcyberforge.xyz`, `https://www.uapcyberforge.xyz`
- **CORS Allowed Origins**: `https://uapcyberforge.xyz`, `https://www.uapcyberforge.xyz`

These settings ensure:
- ✅ Form submissions work correctly
- ✅ AJAX requests are accepted
- ✅ Cross-origin requests from your domains are allowed
- ✅ Cookies and authentication work properly

If you need to add additional domains, set them in `.env`:
```bash
CSRF_TRUSTED_ORIGINS=https://additional-domain.com,https://another-domain.com
CORS_ALLOWED_ORIGINS=https://additional-domain.com,https://another-domain.com
```

### Cloudflare Tunnel

The Cloudflare tunnel is already configured in `docker-compose.yml`. Your platform will be accessible at:
- https://uapcyberforge.xyz
- https://www.uapcyberforge.xyz

## 🗄️ Database

The platform uses SQLite by default. The database file is persisted in `./db.sqlite3` and mounted as a volume in Docker.

### Backup Database
```bash
docker compose exec web python manage.py dumpdata > backup.json
```

### Restore Database
```bash
docker compose exec -T web python manage.py loaddata < backup.json
```

## 📁 File Structure

```
.
├── core/                   # Main Django app
├── ctf/                    # Project settings
├── templates/              # HTML templates
├── static/                 # Static files (CSS, JS, images)
├── media/                  # User-uploaded files
├── Dockerfile              # Docker image definition
├── docker-compose.yml      # Docker services configuration
├── deploy.sh               # Deployment script
├── requirements.txt        # Python dependencies
└── manage.py              # Django management script
```

## 🔒 Security Notes

1. **Always set a strong SECRET_KEY** in production
2. **Keep DEBUG=False** in production
3. **Regularly backup your database**
4. **Monitor logs** for suspicious activity
5. **Keep dependencies updated**

For detailed CSRF and CORS configuration, see [SECURITY.md](SECURITY.md).

## 🐛 Troubleshooting

### Container won't start
```bash
docker compose logs web
```

### Database issues
```bash
docker compose exec web python manage.py migrate
```

### Static files not loading
```bash
docker compose exec web python manage.py collectstatic --noinput
docker compose restart
```

### Cloudflare tunnel issues
```bash
docker compose logs cloudflared
docker compose restart cloudflared
```

## 📝 License

[Your License Here]
