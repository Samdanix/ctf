# 🚀 Quick Start Guide

## Deploy in 5 Minutes

### 1️⃣ Set Up Environment
```bash
# Copy environment template
cp .env.example .env

# Generate a secret key
python -c 'from django.core.management.utils import get_random_secret_key; print(get_random_secret_key())'

# Edit .env and paste the secret key
nano .env  # or use your preferred editor
```

### 2️⃣ Deploy
```bash
# Make deployment script executable
chmod +x deploy.sh

# Run deployment
./deploy.sh
```

### 3️⃣ Initialize Database
```bash
# Make init script executable (Linux/Mac)
chmod +x init_db.sh

# Run database initialization
./init_db.sh

# Or manually run:
docker compose exec web python manage.py migrate
```

### 4️⃣ Create Admin User
```bash
docker compose exec web python manage.py createsuperuser
```

### 5️⃣ Access Your Platform
- **Public Site**: https://uapcyberforge.xyz
- **Admin Panel**: https://uapcyberforge.xyz/secure-mangement-core-9fA7xP3-secure-panel-AlphaZero-2026/

---

## ✅ What's Already Configured

### CSRF Protection ✅
- Trusted origins: `uapcyberforge.xyz`, `www.uapcyberforge.xyz`
- Secure cookies enabled
- Works with forms and AJAX

### CORS Headers ✅
- Allowed origins: `uapcyberforge.xyz`, `www.uapcyberforge.xyz`
- Credentials allowed
- All standard methods enabled

### Security ✅
- HTTPS enforcement
- HSTS headers
- Secure sessions
- Rate limiting
- IP blocking

### Infrastructure ✅
- Docker containerized
- Cloudflare Tunnel configured
- Gunicorn with 4 workers
- Auto-restart on failure
- Database persistence

---

## 📋 Common Commands

### View Logs
```bash
docker compose logs -f              # All services
docker compose logs -f web          # Django only
docker compose logs -f cloudflared  # Tunnel only
```

### Restart Services
```bash
docker compose restart              # Restart all
docker compose restart web          # Restart Django only
```

### Stop Services
```bash
docker compose down
```

### Run Django Commands
```bash
docker compose exec web python manage.py <command>
```

Examples:
```bash
# Create superuser
docker compose exec web python manage.py createsuperuser

# Run migrations
docker compose exec web python manage.py migrate

# Django shell
docker compose exec web python manage.py shell
```

---

## 🔧 Troubleshooting

### CSRF Errors?
Check `CSRF_TRUSTED_ORIGINS` in settings:
```bash
docker compose exec web python manage.py shell
>>> from django.conf import settings
>>> print(settings.CSRF_TRUSTED_ORIGINS)
```

### CORS Errors?
Check `CORS_ALLOWED_ORIGINS` in settings:
```bash
docker compose exec web python manage.py shell
>>> from django.conf import settings
>>> print(settings.CORS_ALLOWED_ORIGINS)
```

### Container Won't Start?
```bash
docker compose logs web
```

### Need to Update?
```bash
git pull
docker compose down
docker compose build
docker compose up -d
docker compose exec web python manage.py migrate
```

---

## 📚 Documentation

- **Full Documentation**: [README.md](README.md)
- **Security Guide**: [SECURITY.md](SECURITY.md)
- **Deployment Checklist**: [DEPLOYMENT_CHECKLIST.md](DEPLOYMENT_CHECKLIST.md)
- **Configuration Summary**: [CONFIGURATION_SUMMARY.txt](CONFIGURATION_SUMMARY.txt)

---

## 🆘 Need Help?

1. Check logs: `docker compose logs -f`
2. Review [SECURITY.md](SECURITY.md) for CSRF/CORS issues
3. Check [DEPLOYMENT_CHECKLIST.md](DEPLOYMENT_CHECKLIST.md)
4. Verify environment variables in `.env`

---

**Your platform is ready to go! 🎉**
