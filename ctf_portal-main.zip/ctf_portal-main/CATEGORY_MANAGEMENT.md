# 📁 Category Management Guide

## Overview

Categories help organize CTF challenges by type (Web, Crypto, Forensics, etc.). This guide explains how to manage categories in your CTF platform.

## Accessing Category Management

1. **Login to Admin Panel**: `https://uapcyberforge.xyz/secure-mangement-core-9fA7xP3-secure-panel-AlphaZero-2026/`
2. **Navigate to Categories**: Click "Categories" in the sidebar under "Manage"

## Creating Categories

### Via Admin Panel (Recommended)

1. Go to **Admin Panel → Categories**
2. Click **"+ New"** button
3. Fill in the form:
   - **Name** (required): Short, descriptive name (e.g., "Web", "Crypto")
   - **Icon** (optional): Emoji icon (e.g., 🌐, 🔐, 🔍)
   - **Description** (optional): Brief description for admins
4. Click **"Create Category"**

### Via Django Shell

```bash
docker compose exec web python manage.py shell
```

```python
from core.models import Category

# Create a single category
Category.objects.create(
    name='Web',
    description='Web exploitation challenges',
    icon='🌐'
)

# Create multiple categories at once
categories = [
    {'name': 'Web', 'description': 'Web exploitation challenges', 'icon': '🌐'},
    {'name': 'Crypto', 'description': 'Cryptography challenges', 'icon': '🔐'},
    {'name': 'Forensics', 'description': 'Digital forensics challenges', 'icon': '🔍'},
    {'name': 'Reverse Engineering', 'description': 'Reverse engineering challenges', 'icon': '⚙️'},
    {'name': 'Pwn', 'description': 'Binary exploitation challenges', 'icon': '💥'},
    {'name': 'Misc', 'description': 'Miscellaneous challenges', 'icon': '🎯'},
]

for cat in categories:
    Category.objects.get_or_create(
        name=cat['name'],
        defaults={'description': cat['description'], 'icon': cat['icon']}
    )
```

## Common CTF Categories

Here are standard categories used in CTF competitions:

| Category | Icon | Description |
|----------|------|-------------|
| **Web** | 🌐 | Web exploitation, XSS, SQL injection, CSRF |
| **Crypto** | 🔐 | Cryptography, encoding, hashing, ciphers |
| **Forensics** | 🔍 | File analysis, steganography, memory dumps |
| **Reverse Engineering** | ⚙️ | Binary analysis, decompilation, debugging |
| **Pwn** | 💥 | Binary exploitation, buffer overflows, ROP |
| **Misc** | 🎯 | Miscellaneous challenges, trivia, puzzles |
| **OSINT** | 🕵️ | Open-source intelligence, reconnaissance |
| **Network** | 🌐 | Packet analysis, protocols, Wireshark |
| **Mobile** | 📱 | Android/iOS app security |
| **Hardware** | 🔧 | Hardware hacking, embedded systems |

## Editing Categories

1. Go to **Admin Panel → Categories**
2. Click **"edit"** next to the category you want to modify
3. Update the fields
4. Click **"Update Category"**

## Deleting Categories

⚠️ **Important**: You cannot delete a category that has challenges assigned to it.

### Steps to Delete:

1. **Reassign or delete all challenges** in that category first
2. Go to **Admin Panel → Categories**
3. Click **"del"** next to the category
4. Confirm deletion

### Check Challenge Count:

```bash
docker compose exec web python manage.py shell
```

```python
from core.models import Category

# See all categories with challenge counts
for cat in Category.objects.all():
    print(f"{cat.name}: {cat.problems.count()} challenges")
```

## Using Categories in Challenges

When creating or editing a challenge:

1. The **Category** dropdown will show all available categories
2. Select the appropriate category for your challenge
3. Categories are **required** for all challenges

## Best Practices

### Naming Conventions

- ✅ Use short, clear names: "Web", "Crypto", "Forensics"
- ❌ Avoid long names: "Web Exploitation and Security"
- ✅ Use standard CTF terminology
- ❌ Don't use abbreviations that aren't widely known

### Icon Selection

- Use relevant emojis that represent the category
- Keep icons consistent across similar categories
- Test icons display correctly in your browser

### Organization

- Start with 5-8 core categories
- Add specialized categories as needed
- Don't create too many categories (keeps things simple)
- Group similar challenge types together

## Troubleshooting

### "Category not found" Error

**Problem**: Getting errors when creating challenges

**Solution**: 
1. Run migrations: `docker compose exec web python manage.py migrate`
2. Create at least one category before creating challenges
3. Use the init script: `./init_db.sh`

### Cannot Delete Category

**Problem**: "Cannot delete category because it has X challenge(s)"

**Solution**:
1. Go to **Admin Panel → Challenges**
2. Filter by the category you want to delete
3. Either:
   - Delete all challenges in that category, OR
   - Reassign challenges to a different category

### Category Dropdown Empty

**Problem**: No categories showing when creating a challenge

**Solution**:
```bash
# Check if categories exist
docker compose exec web python manage.py shell
>>> from core.models import Category
>>> print(Category.objects.count())
>>> exit()

# If count is 0, run init script
./init_db.sh
```

## Database Schema

The Category model has these fields:

```python
class Category(models.Model):
    name = models.CharField(max_length=100)           # Required
    description = models.TextField(blank=True)        # Optional
    icon = models.CharField(max_length=50, blank=True) # Optional
    created_at = models.DateTimeField(auto_now_add=True)
```

## API Access

Categories are accessible via the Problem model:

```python
from core.models import Problem, Category

# Get all challenges in a category
web_category = Category.objects.get(name='Web')
web_challenges = Problem.objects.filter(category=web_category)

# Get category of a challenge
challenge = Problem.objects.get(id=1)
print(challenge.category.name)  # e.g., "Web"
```

## Migration History

Categories were added in the initial migration (`0001_initial.py`). If you're setting up a new instance:

```bash
# Run migrations
docker compose exec web python manage.py migrate

# Initialize default categories
./init_db.sh
```

## Quick Reference Commands

```bash
# List all categories
docker compose exec web python manage.py shell -c "from core.models import Category; [print(f'{c.name} ({c.problems.count()} challenges)') for c in Category.objects.all()]"

# Create a category
docker compose exec web python manage.py shell -c "from core.models import Category; Category.objects.create(name='Web', icon='🌐', description='Web challenges')"

# Delete empty categories
docker compose exec web python manage.py shell -c "from core.models import Category; [c.delete() for c in Category.objects.all() if c.problems.count() == 0]"
```

## Support

If you encounter issues:

1. Check logs: `docker compose logs -f web`
2. Verify migrations: `docker compose exec web python manage.py showmigrations`
3. Check database: `docker compose exec web python manage.py dbshell`

---

**Your categories are now fully dynamic and manageable through the admin panel! 🎉**
