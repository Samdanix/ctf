# Security Configuration Guide

## 🔒 CSRF (Cross-Site Request Forgery) Protection

### What is CSRF?
CSRF protection prevents malicious websites from making unauthorized requests on behalf of authenticated users.

### Configuration
Your platform is configured with:

```python
# In ctf/settings.py
CSRF_COOKIE_HTTPONLY = False  # Allows JavaScript to read CSRF token
CSRF_COOKIE_SAMESITE = 'Lax'  # Prevents cross-site cookie sending
CSRF_COOKIE_SECURE = True     # Only send over HTTPS (production)

CSRF_TRUSTED_ORIGINS = [
    'https://uapcyberforge.xyz',
    'https://www.uapcyberforge.xyz',
]
```

### How to Use CSRF Tokens

#### In HTML Forms:
```html
<form method="post">
    {% csrf_token %}
    <!-- form fields -->
</form>
```

#### In AJAX Requests (JavaScript):
```javascript
// Get CSRF token from cookie
function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

const csrftoken = getCookie('csrftoken');

// Use in fetch request
fetch('/api/endpoint/', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        'X-CSRFToken': csrftoken,
    },
    credentials: 'same-origin',
    body: JSON.stringify(data)
});
```

### Troubleshooting CSRF Errors

**Error: "CSRF verification failed. Request aborted."**

1. **Check CSRF_TRUSTED_ORIGINS**: Ensure your domain is listed
   ```bash
   docker-compose exec web python manage.py shell
   >>> from django.conf import settings
   >>> print(settings.CSRF_TRUSTED_ORIGINS)
   ```

2. **Verify HTTPS**: CSRF tokens require HTTPS in production
   - Check that `CSRF_COOKIE_SECURE = True` is set
   - Verify Cloudflare is serving HTTPS

3. **Check Cookie Settings**: Ensure cookies are being set
   - Open browser DevTools → Application → Cookies
   - Look for `csrftoken` cookie
   - Verify it's not expired or blocked

4. **Add CSRF token to requests**: All POST/PUT/DELETE requests need the token

---

## 🌐 CORS (Cross-Origin Resource Sharing)

### What is CORS?
CORS allows your frontend (if hosted separately) to make requests to your backend API.

### Configuration
Your platform is configured with:

```python
# In ctf/settings.py
CORS_ALLOWED_ORIGINS = [
    'https://uapcyberforge.xyz',
    'https://www.uapcyberforge.xyz',
]

CORS_ALLOW_CREDENTIALS = True  # Allow cookies in cross-origin requests

CORS_ALLOW_METHODS = ['DELETE', 'GET', 'OPTIONS', 'PATCH', 'POST', 'PUT']

CORS_ALLOW_HEADERS = [
    'accept',
    'authorization',
    'content-type',
    'x-csrftoken',
    'x-requested-with',
]
```

### When Do You Need CORS?

You need CORS if:
- Your frontend is on a different domain than your backend
- You're making API requests from JavaScript
- You're building a separate mobile app or SPA

You DON'T need CORS if:
- Your frontend and backend are on the same domain (your current setup)
- You're only using server-side rendered templates

### Troubleshooting CORS Errors

**Error: "Access to fetch at '...' from origin '...' has been blocked by CORS policy"**

1. **Check CORS_ALLOWED_ORIGINS**: Ensure the requesting origin is listed
   ```bash
   docker-compose exec web python manage.py shell
   >>> from django.conf import settings
   >>> print(settings.CORS_ALLOWED_ORIGINS)
   ```

2. **Verify Middleware Order**: CorsMiddleware must be before CommonMiddleware
   ```python
   MIDDLEWARE = [
       'django.middleware.security.SecurityMiddleware',
       'whitenoise.middleware.WhiteNoiseMiddleware',
       'corsheaders.middleware.CorsMiddleware',  # ← Must be here
       'django.middleware.common.CommonMiddleware',
       # ...
   ]
   ```

3. **Check Credentials**: If sending cookies, ensure both are set:
   ```javascript
   // Frontend
   fetch(url, {
       credentials: 'include',  // ← Required
   });
   ```
   ```python
   # Backend
   CORS_ALLOW_CREDENTIALS = True  # ← Required
   ```

4. **Preflight Requests**: CORS sends OPTIONS requests first
   - Check browser DevTools → Network tab
   - Look for OPTIONS request before your actual request
   - Verify it returns 200 OK

---

## 🔐 Additional Security Settings

### Session Security
```python
SESSION_COOKIE_HTTPONLY = True   # Prevent JavaScript access
SESSION_COOKIE_SECURE = True     # HTTPS only (production)
SESSION_COOKIE_SAMESITE = 'Lax'  # CSRF protection
SESSION_COOKIE_AGE = 28800       # 8 hours
```

### HTTPS & SSL
```python
SECURE_SSL_REDIRECT = True                # Redirect HTTP to HTTPS
SECURE_PROXY_SSL_HEADER = ('HTTP_X_FORWARDED_PROTO', 'https')
SECURE_HSTS_SECONDS = 31536000           # 1 year
SECURE_HSTS_INCLUDE_SUBDOMAINS = True
```

### Content Security
```python
SECURE_CONTENT_TYPE_NOSNIFF = True  # Prevent MIME sniffing
X_FRAME_OPTIONS = 'DENY'            # Prevent clickjacking
```

---

## 🧪 Testing Security Configuration

### Test CSRF Protection
```bash
# Should fail without CSRF token
curl -X POST https://uapcyberforge.xyz/submit/ \
  -H "Content-Type: application/json" \
  -d '{"flag":"test"}'

# Should succeed with CSRF token
curl -X POST https://uapcyberforge.xyz/submit/ \
  -H "Content-Type: application/json" \
  -H "X-CSRFToken: YOUR_TOKEN_HERE" \
  -b "csrftoken=YOUR_TOKEN_HERE" \
  -d '{"flag":"test"}'
```

### Test CORS Headers
```bash
# Check CORS headers
curl -I -X OPTIONS https://uapcyberforge.xyz/api/endpoint/ \
  -H "Origin: https://uapcyberforge.xyz" \
  -H "Access-Control-Request-Method: POST"

# Should return:
# Access-Control-Allow-Origin: https://uapcyberforge.xyz
# Access-Control-Allow-Methods: POST, GET, OPTIONS, ...
# Access-Control-Allow-Credentials: true
```

### Test HTTPS Redirect
```bash
# Should redirect to HTTPS
curl -I http://uapcyberforge.xyz/
# Look for: Location: https://uapcyberforge.xyz/
```

---

## 📝 Adding New Domains

If you need to add additional domains:

1. **Update .env file**:
   ```bash
   ALLOWED_HOSTS=uapcyberforge.xyz,www.uapcyberforge.xyz,new-domain.com
   CSRF_TRUSTED_ORIGINS=https://new-domain.com
   CORS_ALLOWED_ORIGINS=https://new-domain.com
   ```

2. **Restart containers**:
   ```bash
   docker-compose restart
   ```

3. **Verify configuration**:
   ```bash
   docker-compose exec web python manage.py shell
   >>> from django.conf import settings
   >>> print(settings.ALLOWED_HOSTS)
   >>> print(settings.CSRF_TRUSTED_ORIGINS)
   >>> print(settings.CORS_ALLOWED_ORIGINS)
   ```

---

## 🚨 Common Issues

### Issue: Forms not submitting
- **Cause**: Missing CSRF token
- **Solution**: Add `{% csrf_token %}` to forms

### Issue: AJAX requests failing
- **Cause**: CSRF token not included in headers
- **Solution**: Add `X-CSRFToken` header to requests

### Issue: Cookies not being set
- **Cause**: HTTPS/Secure cookie mismatch
- **Solution**: Verify HTTPS is working, check `SECURE_PROXY_SSL_HEADER`

### Issue: Cross-origin requests blocked
- **Cause**: Origin not in CORS_ALLOWED_ORIGINS
- **Solution**: Add origin to CORS_ALLOWED_ORIGINS in .env

---

## 📚 Resources

- [Django CSRF Documentation](https://docs.djangoproject.com/en/stable/ref/csrf/)
- [Django CORS Headers](https://github.com/adamchainz/django-cors-headers)
- [OWASP CSRF Prevention](https://cheatsheetseries.owasp.org/cheatsheets/Cross-Site_Request_Forgery_Prevention_Cheat_Sheet.html)
- [MDN CORS Guide](https://developer.mozilla.org/en-US/docs/Web/HTTP/CORS)
