# 🚀 Deployment Checklist

Use this checklist to ensure your CTF platform is properly configured before going live.

## ✅ Pre-Deployment

### 1. Environment Configuration
- [ ] Copy `.env.example` to `.env`
- [ ] Generate and set a strong `SECRET_KEY`
  ```bash
  python -c 'from django.core.management.utils import get_random_secret_key; print(get_random_secret_key())'
  ```
- [ ] Set `DEBUG=False` in `.env`
- [ ] Verify `ALLOWED_HOSTS` includes your domains
- [ ] Review and adjust `DJANGO_LOG_LEVEL` if needed

### 2. Security Settings
- [ ] CSRF trusted origins configured for your domains ✅ (Pre-configured)
- [ ] CORS allowed origins configured for your domains ✅ (Pre-configured)
- [ ] HTTPS enforcement enabled ✅ (Automatic in production)
- [ ] Secure cookies enabled ✅ (Automatic in production)
- [ ] HSTS headers configured ✅ (Pre-configured)

### 3. Cloudflare Tunnel
- [ ] Cloudflare tunnel token is set in `docker-compose.yml` ✅
- [ ] Domains point to Cloudflare tunnel:
  - [ ] `https://uapcyberforge.xyz`
  - [ ] `https://www.uapcyberforge.xyz`

### 4. Docker Configuration
- [ ] Docker and Docker Compose installed on VM
- [ ] Sufficient disk space for database and media files
- [ ] Ports 8000 available (internal only, not exposed publicly)

## 🚀 Deployment Steps

### 1. Initial Setup
```bash
# Clone repository (if needed)
git clone <your-repo-url>
cd <project-directory>

# Set up environment
cp .env.example .env
nano .env  # Edit and set SECRET_KEY

# Make deployment script executable
chmod +x deploy.sh
```

### 2. Deploy
```bash
# Run deployment script
./deploy.sh

# Or manually:
docker-compose build
docker-compose up -d
docker-compose exec web python manage.py migrate
```

### 3. Create Admin User
```bash
docker-compose exec web python manage.py createsuperuser
```

### 4. Verify Deployment
- [ ] Visit `https://uapcyberforge.xyz` - should load homepage
- [ ] Visit `https://www.uapcyberforge.xyz` - should load homepage
- [ ] Check HTTPS is working (green padlock in browser)
- [ ] Test login functionality
- [ ] Test registration functionality
- [ ] Access admin panel: `https://uapcyberforge.xyz/secure-mangement-core-9fA7xP3-secure-panel-AlphaZero-2026/`

## 🧪 Post-Deployment Testing

### 1. Security Tests
```bash
# Check HTTPS redirect
curl -I http://uapcyberforge.xyz/
# Should redirect to https://

# Check security headers
curl -I https://uapcyberforge.xyz/
# Look for:
# - Strict-Transport-Security
# - X-Content-Type-Options: nosniff
# - X-Frame-Options: DENY
```

### 2. Functionality Tests
- [ ] User registration works
- [ ] User login works
- [ ] Challenge submission works
- [ ] File uploads work (if applicable)
- [ ] Leaderboard displays correctly
- [ ] Contest functionality works

### 3. Performance Tests
```bash
# Check container status
docker-compose ps

# Check logs for errors
docker-compose logs web | grep ERROR
docker-compose logs cloudflared | grep ERROR

# Monitor resource usage
docker stats
```

## 📊 Monitoring

### View Logs
```bash
# All services
docker-compose logs -f

# Web service only
docker-compose logs -f web

# Cloudflare tunnel only
docker-compose logs -f cloudflared

# Last 100 lines
docker-compose logs --tail=100 web
```

### Check Service Health
```bash
# Container status
docker-compose ps

# Resource usage
docker stats ctf_web ctf_cloudflared

# Disk usage
docker system df
```

## 🔧 Maintenance

### Regular Tasks
- [ ] **Daily**: Check logs for errors
- [ ] **Weekly**: Review security logs and blocked IPs
- [ ] **Weekly**: Backup database
- [ ] **Monthly**: Update dependencies
- [ ] **Monthly**: Review and rotate secrets if needed

### Backup Database
```bash
# Create backup
docker-compose exec web python manage.py dumpdata > backup_$(date +%Y%m%d).json

# Or backup SQLite file directly
docker cp ctf_web:/app/db.sqlite3 ./backup_$(date +%Y%m%d).sqlite3
```

### Update Application
```bash
# Pull latest code
git pull

# Rebuild and restart
docker-compose down
docker-compose build
docker-compose up -d

# Run migrations
docker-compose exec web python manage.py migrate

# Collect static files
docker-compose exec web python manage.py collectstatic --noinput
```

### Update Dependencies
```bash
# Update requirements.txt with new versions
# Then rebuild
docker-compose build --no-cache
docker-compose up -d
```

## 🚨 Troubleshooting

### Container Won't Start
```bash
# Check logs
docker-compose logs web

# Common issues:
# - Missing .env file
# - Invalid SECRET_KEY
# - Port already in use
# - Insufficient permissions
```

### CSRF Errors
```bash
# Verify CSRF settings
docker-compose exec web python manage.py shell
>>> from django.conf import settings
>>> print(settings.CSRF_TRUSTED_ORIGINS)
>>> print(settings.ALLOWED_HOSTS)
```

### CORS Errors
```bash
# Verify CORS settings
docker-compose exec web python manage.py shell
>>> from django.conf import settings
>>> print(settings.CORS_ALLOWED_ORIGINS)
>>> print(settings.CORS_ALLOW_CREDENTIALS)
```

### Cloudflare Tunnel Issues
```bash
# Check tunnel logs
docker-compose logs cloudflared

# Restart tunnel
docker-compose restart cloudflared

# Verify tunnel token is correct in docker-compose.yml
```

### Database Issues
```bash
# Run migrations
docker-compose exec web python manage.py migrate

# Check migration status
docker-compose exec web python manage.py showmigrations

# Create new migration (if models changed)
docker-compose exec web python manage.py makemigrations
```

### Static Files Not Loading
```bash
# Collect static files
docker-compose exec web python manage.py collectstatic --noinput

# Restart web service
docker-compose restart web
```

## 📞 Support

If you encounter issues:

1. Check logs: `docker-compose logs -f`
2. Review [SECURITY.md](SECURITY.md) for CSRF/CORS issues
3. Check [README.md](README.md) for general documentation
4. Verify all checklist items above are completed

## 🎉 Success Criteria

Your deployment is successful when:
- ✅ Both domains load over HTTPS
- ✅ Users can register and login
- ✅ Challenges can be submitted
- ✅ Admin panel is accessible
- ✅ No errors in logs
- ✅ Security headers are present
- ✅ CSRF protection is working
- ✅ Cloudflare tunnel is connected

---

**Last Updated**: May 5, 2026
**Platform**: Django CTF Platform
**Domains**: uapcyberforge.xyz, www.uapcyberforge.xyz
