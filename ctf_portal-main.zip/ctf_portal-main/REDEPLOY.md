# 🔄 Redeployment Instructions

The configuration has been fixed. The database will now be stored in a Docker volume for proper persistence.

## Run these commands:

```bash
# Stop and remove existing containers
docker compose down

# Remove old volumes (if any)
docker volume rm ctf_portal-main_db_data 2>/dev/null || true

# Rebuild with the fixed configuration
docker compose build --no-cache

# Start the services
docker compose up -d

# Wait a moment for services to start
sleep 5

# Run migrations
docker compose exec web python manage.py migrate

# Create your admin user
docker compose exec web python manage.py createsuperuser
```

## ✅ Your site will be live at:
- https://uapcyberforge.xyz
- https://www.uapcyberforge.xyz

## 📊 Check status:
```bash
docker compose ps
docker compose logs -f
```

## What was fixed:
1. ✅ Removed obsolete `version` field from docker-compose.yml
2. ✅ Changed database storage to use Docker volume instead of bind mount
3. ✅ Fixed database path in settings.py
4. ✅ Created db_data directory in Dockerfile
5. ✅ Proper permissions for database file creation
