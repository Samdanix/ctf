#!/bin/bash

# Database Initialization Script
# Run this after first deployment to set up the database

set -e

echo "🔧 Initializing CTF Platform Database..."

# Check if Docker Compose is available
if docker compose version &> /dev/null; then
    DOCKER_COMPOSE="docker compose"
elif command -v docker-compose &> /dev/null; then
    DOCKER_COMPOSE="docker-compose"
else
    echo "❌ Docker Compose is not installed."
    exit 1
fi

# Run migrations
echo "📦 Running database migrations..."
$DOCKER_COMPOSE exec -T web python manage.py migrate

# Create default categories
echo "📁 Creating default categories..."
$DOCKER_COMPOSE exec -T web python manage.py shell <<EOF
from core.models import Category

categories = [
    {'name': 'Web', 'description': 'Web exploitation challenges', 'icon': '🌐'},
    {'name': 'Crypto', 'description': 'Cryptography challenges', 'icon': '🔐'},
    {'name': 'Forensics', 'description': 'Digital forensics challenges', 'icon': '🔍'},
    {'name': 'Reverse Engineering', 'description': 'Reverse engineering challenges', 'icon': '⚙️'},
    {'name': 'Pwn', 'description': 'Binary exploitation challenges', 'icon': '💥'},
    {'name': 'Misc', 'description': 'Miscellaneous challenges', 'icon': '🎯'},
]

for cat in categories:
    obj, created = Category.objects.get_or_create(
        name=cat['name'],
        defaults={'description': cat['description'], 'icon': cat['icon']}
    )
    if created:
        print(f"✅ Created category: {cat['name']}")
    else:
        print(f"ℹ️  Category already exists: {cat['name']}")

print("\\n✅ Default categories initialized!")
EOF

echo ""
echo "✅ Database initialization complete!"
echo ""
echo "📝 Next steps:"
echo "   1. Create a superuser: $DOCKER_COMPOSE exec web python manage.py createsuperuser"
echo "   2. Login to admin: https://uapcyberforge.xyz/admin/"
echo "   3. You can now add/edit/delete categories from the admin panel"
echo ""

