from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from core import views
from core import admin_views

# Secret admin panel base URL
_ADMIN = 'secure-mangement-core-9fA7xP3-secure-panel-AlphaZero-2026'

urlpatterns = [
    # Django built-in admin (hidden under the secret prefix too)
    path(f'{_ADMIN}/django/', admin.site.urls),

    # ── Custom Admin Panel ────────────────────────────────────────────────
    path(f'{_ADMIN}/login/',                                              admin_views.admin_login,                 name='custom_admin_login'),
    path(f'{_ADMIN}/',                                                    admin_views.admin_dashboard,             name='custom_admin_dashboard'),
    path(f'{_ADMIN}/challenges/',                                         admin_views.admin_challenges,            name='custom_admin_challenges'),
    path(f'{_ADMIN}/challenges/view/<int:challenge_id>/',                 admin_views.admin_view_challenge,        name='custom_admin_view_challenge'),
    path(f'{_ADMIN}/challenges/edit/<int:challenge_id>/',                 admin_views.admin_edit_challenge,        name='custom_admin_edit_challenge'),
    path(f'{_ADMIN}/challenges/delete/<int:challenge_id>/',               admin_views.admin_delete_challenge,      name='custom_admin_delete_challenge'),
    path(f'{_ADMIN}/challenges/toggle/<int:challenge_id>/',               admin_views.admin_toggle_challenge,      name='custom_admin_toggle_challenge'),
    path(f'{_ADMIN}/contests/',                                           admin_views.admin_contests,              name='custom_admin_contests'),
    path(f'{_ADMIN}/contests/view/<int:contest_id>/',                     admin_views.admin_view_contest,          name='custom_admin_view_contest'),
    path(f'{_ADMIN}/contests/<int:contest_id>/scoreboard/',               admin_views.admin_contest_scoreboard,    name='custom_admin_contest_scoreboard'),
    path(f'{_ADMIN}/contests/<int:contest_id>/add-challenge/',            admin_views.admin_contest_add_challenge, name='custom_admin_contest_add_challenge'),
    path(f'{_ADMIN}/contests/<int:contest_id>/remove/<int:challenge_id>/',admin_views.admin_contest_remove_challenge, name='custom_admin_contest_remove_challenge'),
    path(f'{_ADMIN}/contests/delete/<int:contest_id>/',                   admin_views.admin_delete_contest,        name='custom_admin_delete_contest'),
    path(f'{_ADMIN}/contests/end/<int:contest_id>/',                      admin_views.admin_end_contest,           name='custom_admin_end_contest'),
    path(f'{_ADMIN}/contests/<int:contest_id>/freeze/',                   admin_views.admin_freeze_leaderboard,    name='custom_admin_freeze_leaderboard'),
    path(f'{_ADMIN}/contests/<int:contest_id>/unfreeze/',                 admin_views.admin_unfreeze_leaderboard,  name='custom_admin_unfreeze_leaderboard'),
    path(f'{_ADMIN}/users/',                                              admin_views.admin_users,                 name='custom_admin_users'),
    path(f'{_ADMIN}/users/ban/<int:user_id>/',                            admin_views.admin_ban_user,              name='custom_admin_ban_user'),
    path(f'{_ADMIN}/users/delete/<int:user_id>/',                         admin_views.admin_delete_user,           name='custom_admin_delete_user'),
    path(f'{_ADMIN}/users/block-ip/<int:user_id>/',                       admin_views.admin_block_user_ip,         name='custom_admin_block_user_ip'),
    path(f'{_ADMIN}/blocked-ips/',                                        admin_views.admin_blocked_ips,           name='custom_admin_blocked_ips'),
    path(f'{_ADMIN}/blocked-ips/add/',                                    admin_views.admin_block_ip_manual,       name='custom_admin_block_ip_manual'),
    path(f'{_ADMIN}/blocked-ips/unblock/<int:blocked_id>/',               admin_views.admin_unblock_ip,            name='custom_admin_unblock_ip'),
    path(f'{_ADMIN}/submissions/',                                        admin_views.admin_submissions,           name='custom_admin_submissions'),
    path(f'{_ADMIN}/activity-log/',                                       admin_views.admin_activity_log,          name='custom_admin_activity_log'),
    path(f'{_ADMIN}/new-challenge/',                                      admin_views.admin_new_challenge,         name='custom_admin_new_challenge'),
    path(f'{_ADMIN}/new-contest/',                                        admin_views.admin_new_contest,           name='custom_admin_new_contest'),
    path(f'{_ADMIN}/announce/',                                           admin_views.admin_announce,              name='custom_admin_announce'),
    path(f'{_ADMIN}/announce/edit/<int:announcement_id>/',                admin_views.admin_edit_announcement,     name='custom_admin_edit_announcement'),
    path(f'{_ADMIN}/announce/delete/<int:announcement_id>/',              admin_views.admin_delete_announcement,   name='custom_admin_delete_announcement'),
    path(f'{_ADMIN}/announce/toggle/<int:announcement_id>/',              admin_views.admin_toggle_announcement,   name='custom_admin_toggle_announcement'),
    path(f'{_ADMIN}/settings/',                                           admin_views.admin_settings,              name='custom_admin_settings'),
    
    # Categories
    path(f'{_ADMIN}/categories/',                                         admin_views.admin_categories,            name='custom_admin_categories'),
    path(f'{_ADMIN}/categories/new/',                                     admin_views.admin_new_category,          name='custom_admin_new_category'),
    path(f'{_ADMIN}/categories/edit/<int:category_id>/',                  admin_views.admin_edit_category,         name='custom_admin_edit_category'),
    path(f'{_ADMIN}/categories/delete/<int:category_id>/',                admin_views.admin_delete_category,       name='custom_admin_delete_category'),

    # ── Main pages ────────────────────────────────────────────────────────
    path('', views.home, name='home'),
    path('challenges/', views.challenges, name='challenges'),
    path('challenge/<int:problem_id>/', views.challenge_detail, name='challenge_detail'),
    path('challenge/<int:problem_id>/submit/', views.submit_flag, name='submit_flag'),
    path('challenge/<int:problem_id>/download/', views.download_challenge_file, name='download_challenge_file'),

    # Contests
    path('contests/', views.contests, name='contests'),
    path('contest/<int:contest_id>/', views.contest_detail, name='contest_detail'),

    # Leaderboard
    path('leaderboard/', views.leaderboard, name='leaderboard'),

    # User
    path('register/', views.register, name='register'),
    path('login/', views.user_login, name='login'),
    path('logout/', views.user_logout, name='logout'),
    path('profile/', views.profile, name='profile'),
    path('profile/<str:username>/', views.profile, name='user_profile'),

    # API
    path('api/leaderboard/', views.api_leaderboard, name='api_leaderboard'),
]

# Serve media files in development
# In production, serve /media/ via your web server (Nginx/Apache) or a CDN.
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
