import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

# ─────────────────────────────────────────────────────────────────────────────
# SECRET KEY — read from environment; fall back to a dev-only value that is
# never used in production.  Set the SECRET_KEY env-var before deploying.
# ─────────────────────────────────────────────────────────────────────────────
SECRET_KEY = os.environ.get(
    'SECRET_KEY',
    'django-insecure-dev-only-change-me-before-deploying-to-production'
)

# ─────────────────────────────────────────────────────────────────────────────
# DEBUG — always False in production; override with DEBUG=True env-var locally
# ─────────────────────────────────────────────────────────────────────────────
DEBUG = os.environ.get('DEBUG', 'False').lower() == 'true'

# ─────────────────────────────────────────────────────────────────────────────
# ALLOWED HOSTS — set via env-var in production, e.g.:
#   ALLOWED_HOSTS=yourdomain.com,www.yourdomain.com
# ─────────────────────────────────────────────────────────────────────────────
_allowed = os.environ.get('ALLOWED_HOSTS', '')
ALLOWED_HOSTS = [h.strip() for h in _allowed.split(',') if h.strip()] or (['localhost', '127.0.0.1'] if DEBUG else ['localhost', '127.0.0.1'])

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'corsheaders',  # CORS support
    'core',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'whitenoise.middleware.WhiteNoiseMiddleware',               # Static file serving (production)
    'corsheaders.middleware.CorsMiddleware',                    # CORS headers (must be before CommonMiddleware)
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',  # Clickjacking protection
    'core.middleware.BlockedIPMiddleware',                      # IP block list
    'core.middleware.SecurityHeadersMiddleware',                # Custom security headers
    'core.middleware.RateLimitMiddleware',                      # Rate limiting
]

ROOT_URLCONF = 'ctf.urls'

TEMPLATES = [{
    'BACKEND': 'django.template.backends.django.DjangoTemplates',
    'DIRS': [BASE_DIR / "templates"],
    'APP_DIRS': True,
    'OPTIONS': {'context_processors': [
        'django.template.context_processors.debug',
        'django.template.context_processors.request',
        'django.contrib.auth.context_processors.auth',
        'django.contrib.messages.context_processors.messages',
    ]},
}]

WSGI_APPLICATION = 'ctf.wsgi.application'

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db_data' / 'db.sqlite3',
    }
}

# ─────────────────────────────────────────────────────────────────────────────
# PASSWORD VALIDATION
# ─────────────────────────────────────────────────────────────────────────────
AUTH_PASSWORD_VALIDATORS = [
    {'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator'},
    {'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator', 'OPTIONS': {'min_length': 8}},
    {'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator'},
    {'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator'},
]

# ─────────────────────────────────────────────────────────────────────────────
# INTERNATIONALISATION
# ─────────────────────────────────────────────────────────────────────────────
LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'UTC'
USE_I18N = True
USE_TZ = True

# ─────────────────────────────────────────────────────────────────────────────
# STATIC & MEDIA FILES
# ─────────────────────────────────────────────────────────────────────────────
STATIC_URL = '/static/'
STATICFILES_DIRS = [BASE_DIR / 'static']
STATIC_ROOT = BASE_DIR / 'staticfiles'

# WhiteNoise compressed static file storage for production
STATICFILES_STORAGE = 'whitenoise.storage.CompressedManifestStaticFilesStorage'

MEDIA_URL = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# ─────────────────────────────────────────────────────────────────────────────
# AUTH REDIRECTS
# ─────────────────────────────────────────────────────────────────────────────
LOGIN_URL = 'login'
LOGIN_REDIRECT_URL = 'home'
LOGOUT_REDIRECT_URL = 'home'

# staff_member_required redirects here when the user is not staff
ADMIN_LOGIN_URL = '/secure-mangement-core-9fA7xP3-secure-panel-AlphaZero-2026/login/'

# ─────────────────────────────────────────────────────────────────────────────
# SESSION SECURITY
# ─────────────────────────────────────────────────────────────────────────────
SESSION_COOKIE_HTTPONLY = True          # JS cannot read the session cookie
SESSION_COOKIE_SAMESITE = 'Lax'        # CSRF mitigation for cross-site requests
SESSION_COOKIE_AGE = 60 * 60 * 8       # 8-hour sessions
SESSION_EXPIRE_AT_BROWSER_CLOSE = False

# In production (HTTPS) also set:
#   SESSION_COOKIE_SECURE = True
if not DEBUG:
    SESSION_COOKIE_SECURE = True

# ─────────────────────────────────────────────────────────────────────────────
# CSRF SECURITY
# ─────────────────────────────────────────────────────────────────────────────
CSRF_COOKIE_HTTPONLY = False   # Must be False so JS can read it for AJAX
CSRF_COOKIE_SAMESITE = 'Lax'
CSRF_USE_SESSIONS = False      # Keep cookie-based CSRF (simpler for this app)

if not DEBUG:
    CSRF_COOKIE_SECURE = True

# CSRF Trusted Origins — required for POST requests from your domains
CSRF_TRUSTED_ORIGINS = [
    'https://uapcyberforge.xyz',
    'https://www.uapcyberforge.xyz',
]

# Add additional origins from environment variable if needed
_csrf_origins = os.environ.get('CSRF_TRUSTED_ORIGINS', '')
if _csrf_origins:
    CSRF_TRUSTED_ORIGINS.extend([o.strip() for o in _csrf_origins.split(',') if o.strip()])

# ─────────────────────────────────────────────────────────────────────────────
# CORS (Cross-Origin Resource Sharing) CONFIGURATION
# ─────────────────────────────────────────────────────────────────────────────
# Allow requests from your domains
CORS_ALLOWED_ORIGINS = [
    'https://uapcyberforge.xyz',
    'https://www.uapcyberforge.xyz',
]

# Add additional CORS origins from environment variable if needed
_cors_origins = os.environ.get('CORS_ALLOWED_ORIGINS', '')
if _cors_origins:
    CORS_ALLOWED_ORIGINS.extend([o.strip() for o in _cors_origins.split(',') if o.strip()])

# Allow credentials (cookies, authorization headers) in CORS requests
CORS_ALLOW_CREDENTIALS = True

# Allowed HTTP methods
CORS_ALLOW_METHODS = [
    'DELETE',
    'GET',
    'OPTIONS',
    'PATCH',
    'POST',
    'PUT',
]

# Allowed headers in CORS requests
CORS_ALLOW_HEADERS = [
    'accept',
    'accept-encoding',
    'authorization',
    'content-type',
    'dnt',
    'origin',
    'user-agent',
    'x-csrftoken',
    'x-requested-with',
]

# For development: allow all origins (NEVER use in production!)
# CORS_ALLOW_ALL_ORIGINS = True  # Uncomment only for local development

# ─────────────────────────────────────────────────────────────────────────────
# SECURITY HEADERS (django.middleware.security.SecurityMiddleware)
# ─────────────────────────────────────────────────────────────────────────────
SECURE_CONTENT_TYPE_NOSNIFF = True      # X-Content-Type-Options: nosniff
SECURE_BROWSER_XSS_FILTER = True        # X-XSS-Protection (legacy browsers)
X_FRAME_OPTIONS = 'DENY'               # Clickjacking: deny all framing

# HSTS — only enable when the site is served over HTTPS
if not DEBUG:
    SECURE_SSL_REDIRECT = True
    SECURE_HSTS_SECONDS = 31536000          # 1 year
    SECURE_HSTS_INCLUDE_SUBDOMAINS = True
    SECURE_HSTS_PRELOAD = True
    SECURE_PROXY_SSL_HEADER = ('HTTP_X_FORWARDED_PROTO', 'https')

# ─────────────────────────────────────────────────────────────────────────────
# FILE UPLOAD SECURITY
# ─────────────────────────────────────────────────────────────────────────────
# Maximum upload size: 50 MB
DATA_UPLOAD_MAX_MEMORY_SIZE = 52_428_800   # 50 MB
FILE_UPLOAD_MAX_MEMORY_SIZE = 52_428_800   # 50 MB

# Allowed challenge file extensions (enforced in admin_views.py)
ALLOWED_CHALLENGE_EXTENSIONS = {
    '.zip', '.tar', '.gz', '.tar.gz', '.7z',
    '.pdf', '.txt', '.png', '.jpg', '.jpeg',
    '.pcap', '.pcapng', '.bin', '.elf', '.exe',
    '.py', '.c', '.cpp', '.js', '.html',
}

# ─────────────────────────────────────────────────────────────────────────────
# RATE LIMITING (simple in-memory; use django-ratelimit for production)
# ─────────────────────────────────────────────────────────────────────────────
FLAG_SUBMISSION_RATE_LIMIT = 10   # max submissions per minute per user
LOGIN_RATE_LIMIT = 5              # max login attempts per minute per IP

# ─────────────────────────────────────────────────────────────────────────────
# LOGGING
# ─────────────────────────────────────────────────────────────────────────────
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'verbose': {
            'format': '{levelname} {asctime} {module} {process:d} {thread:d} {message}',
            'style': '{',
        },
    },
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
            'formatter': 'verbose',
        },
    },
    'root': {
        'handlers': ['console'],
        'level': 'WARNING',
    },
    'loggers': {
        'django': {
            'handlers': ['console'],
            'level': os.environ.get('DJANGO_LOG_LEVEL', 'WARNING'),
            'propagate': False,
        },
        'core': {
            'handlers': ['console'],
            'level': 'INFO',
            'propagate': False,
        },
    },
}

# ─────────────────────────────────────────────────────────────────────────────
# Ensure media directory exists at startup
# ─────────────────────────────────────────────────────────────────────────────
import os as _os
_os.makedirs(MEDIA_ROOT, exist_ok=True)
