# 📋 Quick Reference - Category Management

## 🚀 First Time Setup

```bash
# 1. Run migrations
docker compose exec web python manage.py migrate

# 2. Initialize default categories
bash init_db.sh

# 3. Access admin panel
# URL: https://uapcyberforge.xyz/secure-mangement-core-9fA7xP3-secure-panel-AlphaZero-2026/
# Click: Categories (in sidebar)
```

## 🎯 Common Tasks

### Create a Category (Admin Panel)
1. Admin Panel → Categories → "+ New"
2. Fill in: Name, Icon (emoji), Description
3. Click "Create Category"

### Create a Category (Command Line)
```bash
docker compose exec web python manage.py shell -c "
from core.models import Category
Category.objects.create(name='Web', icon='🌐', description='Web challenges')
"
```

### List All Categories
```bash
docker compose exec web python manage.py shell -c "
from core.models import Category
for c in Category.objects.all():
    print(f'{c.icon} {c.name} - {c.problems.count()} challenges')
"
```

### Delete Empty Categories
```bash
docker compose exec web python manage.py shell -c "
from core.models import Category
for c in Category.objects.all():
    if c.problems.count() == 0:
        print(f'Deleting: {c.name}')
        c.delete()
"
```

## 📁 Standard CTF Categories

Copy-paste these into the admin panel:

| Name | Icon | Description |
|------|------|-------------|
| Web | 🌐 | Web exploitation challenges |
| Crypto | 🔐 | Cryptography challenges |
| Forensics | 🔍 | Digital forensics challenges |
| Reverse Engineering | ⚙️ | Reverse engineering challenges |
| Pwn | 💥 | Binary exploitation challenges |
| Misc | 🎯 | Miscellaneous challenges |
| OSINT | 🕵️ | Open-source intelligence |
| Network | 🌐 | Packet analysis challenges |

## 🔧 Troubleshooting

### No categories showing?
```bash
# Check count
docker compose exec web python manage.py shell -c "
from core.models import Category
print(f'Total categories: {Category.objects.count()}')
"

# If 0, run init script
bash init_db.sh
```

### Can't delete category?
**Reason**: Category has challenges assigned to it

**Solution**: Reassign or delete those challenges first

```bash
# Check which challenges use this category
docker compose exec web python manage.py shell -c "
from core.models import Category, Problem
cat = Category.objects.get(name='Web')
for p in cat.problems.all():
    print(f'- {p.title}')
"
```

### Category dropdown empty when creating challenge?
**Reason**: No categories exist yet

**Solution**: Create at least one category first!

## 📍 Admin Panel URLs

```
Base: /secure-mangement-core-9fA7xP3-secure-panel-AlphaZero-2026/

Categories:
  List:   /categories/
  New:    /categories/new/
  Edit:   /categories/edit/<id>/
  Delete: /categories/delete/<id>/
```

## 💡 Pro Tips

1. **Start with 5-8 core categories** - Don't create too many
2. **Use emojis for visual appeal** - Makes the UI more engaging
3. **Keep names short** - "Web" not "Web Exploitation and Security"
4. **Test before deleting** - Make sure no challenges use the category
5. **Use standard CTF names** - Helps users familiar with CTF competitions

## 🔗 Related Files

- **Full Guide**: `CATEGORY_MANAGEMENT.md`
- **Setup Summary**: `SETUP_SUMMARY.md`
- **Quick Start**: `QUICK_START.md`
- **Init Script**: `init_db.sh`

## 📞 Quick Commands Cheat Sheet

```bash
# Create category
docker compose exec web python manage.py shell -c "from core.models import Category; Category.objects.create(name='Web', icon='🌐')"

# List categories
docker compose exec web python manage.py shell -c "from core.models import Category; [print(c.name) for c in Category.objects.all()]"

# Count challenges per category
docker compose exec web python manage.py shell -c "from core.models import Category; [print(f'{c.name}: {c.problems.count()}') for c in Category.objects.all()]"

# Delete category (only if empty)
docker compose exec web python manage.py shell -c "from core.models import Category; Category.objects.get(name='OldCategory').delete()"

# Bulk create categories
docker compose exec web python manage.py shell < init_categories.py
```

---

**Everything you need to manage categories! 🎉**
