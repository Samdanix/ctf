#!/bin/bash

echo "Testing Docker Compose detection..."

if docker compose version &> /dev/null; then
    echo "✅ Docker Compose v2 detected"
    docker compose version
elif command -v docker-compose &> /dev/null; then
    echo "✅ Docker Compose v1 detected"
    docker-compose version
else
    echo "❌ Docker Compose not found"
fi
